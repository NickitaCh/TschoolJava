package com.tsystems.javaschool.websecurity;

public class DataDto {

    String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
