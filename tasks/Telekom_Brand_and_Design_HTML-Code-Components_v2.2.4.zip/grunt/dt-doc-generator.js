/*
 * 
 * 
 *
 * Copyright (c) 2012 "Cowboy" Ben Alman, contributors
 * Licensed under the MIT license.
 */

'use strict';

var markdown = require('marked');

module.exports = function (grunt) {

  // Internal lib.
  grunt.registerMultiTask('dtdocs', 'Generate doc files for jekyll.', function () {

    // Merge task-specific and/or target-specific options with these defaults.
    var options = this.options({
      separator: grunt.util.linefeed,
      markdownOptions: {}
    });

    markdown.Renderer.prototype.code = function (code, lang, escaped) {
      return '{% highlight ' + (lang || 'html') + ' %}' + code + '{% endhighlight %}';
    }

    markdown.setOptions(options.markdownOptions);

    // Iterate over all src-dest file pairs.
    this.files.forEach(function (f) {

      var jekyllHead = '---\nlayout: default\ntitle: ' + f.title + '\n---\n\n';
      var src = jekyllHead + f.src.filter(function (filepath) {
        // Warn on and remove invalid source files (if nonull was set).
        if (!grunt.file.exists(filepath)) {
          grunt.log.warn('Source file "' + filepath + '" not found.');
          return false;
        } else {
          return true;
        }
      }).map(function (filepath) {

        // Read file source.
        var src = grunt.file.read(filepath);

//        process if needed

        return markdown(src); //, options.markdownDialect, options.markdownOptions);
      }).join(options.separator);

      // Write the destination file.
      grunt.file.write(f.dest, src);

      // Print a success message.
      grunt.log.writeln('File "' + f.dest + '" created.');
    });

  });

};
