<!--
//
//
// Formulare
-->

Der HTML-Standard bietet verschiedenste Eingabefelder. Aufgrund dieser Vielfalt können Elemente nur sinnvoll gestaltet werden, wenn sie individuell behandelt werden. Daher werden im folgenden Abschnitt die Eingabefelder der Komponenten im Detail betrachtet.

## Texteingaben

### Einfache Eingabefelder

Die einfachste Form des Eingabefelds ist das `<input>`-Feld. HTML5 sieht hierfür verschiedenste Typen vor. Im einfachsten Fall handelt es sich dabei um den Typ `<input type="text">`. Durch die CSS-Klasse `.form-input` kann das gewünschte Aussehen und Verhalten angewendet werden.

Da Eingabefelder immer in Kombination mit einer Beschriftung erscheinen sollten, werden sie mit einem `<div>`-Tag mit der CSS-Klasse `.form-input-set`
ummantelt. Es schafft die Anordnung von Eingabefeld und Beschriftung:

<div class="tc-example">
  <div class="form-input-set">
    <label for="text1">Standard Eingabefeld</label>
    <input type="text" class="form-input" name="text1" id="text1" placeholder="Placeholder">
  </div>
</div>

```html
<div class="form-input-set"> 
  <label for="text1">Standard Eingabefeld</label> 
  <input type="text" class="form-input" name="text1" id="text1" placeholder="..."> 
</div> 
```

<div class="tc-note tc-note-info">
**Tipp:**
Das Attribut <code>placehoder="Placeholder"</code> sorgt für das Erscheinen eines Platzhaltertextes, wenn das Element leer ist. So kann der Benutzer gezeigt werden, was dort einzutragen ist.
Hinweis: Das Placeholder-Attribut ist im Internet-Explorer kleiner
Version 9 nicht verfügbar.
</div>

### Mehrzeilige Eingabefelder

Für lange Texte ist in HTML der `<textarea>`-Tag vorgesehen.
Da die Eingabe dem einfachen Eingabefeld sehr ähnelt, kann ebenfalls die CSS-Klasse `.form-input` angewendet werden:

<div class="tc-example">
  <div class="form-input-set">
    <label for="text2">Lange Texteingabe</label>
    <textarea class="form-input" name="text2" id="text2">Lorem ipsum...
    </textarea>
  </div>
</div>

```html
<div class="form-input-set">
  <label for="text2">Lange Texteingabe</label>
  <textarea class="form-input" name="text2" id="text2">Lorem ipsum...</textarea>
</div>
```

### Funktionale Dekorationen

Um dem Benutzer ein angemessenes Eingabe-Feedback zu bieten, werden verschiedene Dekorationen für Formularfelder angeboten. Die CSS-Klassen `.decoration-positive`,
`.decoration-warning` und `.decoration-negative` werden dabei auf das umgebene `<div>`-Tag angewendet um auch das `<label>` beeinflussen zu können:

<div class="tc-example">
  <div class="form-input-set decoration-positive">
    <label for="text3">Erfolgreich Eingabefeld</label>
    <input type="text" class="form-input" name="text3" id="text3" placeholder="Placeholder">
  </div>
  <div class="form-input-set decoration-warning">
    <label for="text4">Warnung Eingabefeld</label>
    <input type="text" class="form-input" name="text4" id="text4" placeholder="Placeholder">
  </div>
  <div class="form-input-set decoration-negative">
    <label for="text5">Erfolglos Eingabefeld</label>
    <input type="text" class="form-input" name="text5" id="text5" placeholder="Placeholder">
  </div>
  <div class="form-input-set">
    <label for="text6">Inaktives Eingabefeld</label>
    <input type="text" class="form-input" name="text6" id="text6" placeholder="Placeholder" disabled="disabled">
  </div>
</div>

```html
<!-- Erfolgreich Eingabefeld --> 
<div class="form-input-set decoration-positive">...</div> 
 
<!-- Warnung Eingabefeld --> 
<div class="form-input-set decoration-warning">...</div> 
 
<!-- Erfolglos Eingabefeld --> 
<div class="form-input-set decoration-negative">...</div> 
 
<!-- Inaktiv Eingabefeld --> 
<input type="text" class="form-input" name="text6" id="text6" disabled="disabled"> 
```

<div class="tc-note">
**Anmerkung Barrierefreiheit:**
Die eingesetzen Farben haben im Zusammenhang mit Eingabefeldern meist die 
Funktion der visuellen Rückmeldung über eine getätigte Eingabe. Diese wird
von Unterstützungstechnologien in der Regel nicht erkannt. Deshlab sollte zur
visuellen Rückmeldung auch unbedingt eine textuelle Rückmeldung wie:
"Dies ist ein Pflichtfeld, bitte geben Sie ihren Vornamen ein" oder ähnliches
erfolgen.
</div>

### Fieldsets

Um Eingabefelder logisch zusammenfassen ist das `<fieldset>`-Tag vorgesehen.
Der `<legend>`-Tag sorgt dabei für die nötige Beschriftung der Gruppe:

<div class="tc-example">
  <fieldset class="form-fieldset">
    <legend>Benutzerdaten</legend>
    <div class="form-input-set">
      <label for="text7">Login</label>
      <input type="text" class="form-input" name="text7" id="text7" placeholder="Login">
    </div>
    <div class="form-input-set">
      <label for="text8">Password</label>
      <input type="password" class="form-input" name="text8" id="text8" placeholder="Password">
    </div>
  </fieldset>
</div>

```html
<fieldset class="form-fieldset">
  <legend>Benutzerdaten</legend>
  ...
</fieldset>
```

<div class="tc-note">
**Anmerkung:**
Das <code>fieldset</code> hat im Bezug auf die Größenberechnung je nach Browser unterschiedliche Verhalten.
Ziel ist es meist, dass das Formular unabhängig von der umliegenden Seite in jedem Fall komplett und nicht
bschnitten angezeigt wird. Das hat aber auch zur Folge, dass die CSS-Klasse `.text-ellipsed` innerhalb
des <code>fieldset</code> nicht greift.
</div>