<!--
//
//
// Helfer
-->

Die Komponenten stellen neben den gängigen Elementen diverse Helfer zur Verfügung. Bei ihnen handelt es sich meistens um CSS-Klassen, die in den verschiedensten Fällen zum Einsatz kommen. Im Folgenden werden diese Helfer kurz mit Einsatzzweck und Beispiel vorgestellt.

## Clearfix

Die CSS-Klasse `.clearfix` ist dafür zuständig, CSS-Floatings aufzuheben. Sie wird in der Regel auf das umgebende HTML-Element angewendet:

<div class="tc-example">
  <div class="clearfix">
    <div style="float: left;">Ich bin links</div>
    <div style="float: right;">Ich bin rechts</div>
  </div>
  <p>Ich folge wieder der normalen Anordnung</p>
</div>

```html
<div class="clearfix">
  <div style="float: left;">Ich bin links</div>
  <div style="float: right;">Ich bin rechts</div>
</div>
<p>Ich folge wieder der normalen Anordnung</p>
```

## Elemente verstecken und Zeigen

Sollen Elemente gänzlich verschwinden, hilft die CSS-Klasse `.hidden`.
Sie versteckt Elemente auch vor Screen-Readern.

```html
<button type="button" class="hidden">Unsichtbar</button>
```

## Elemente Responsiv verstecken
Sollen Elemente responsiv verschwinden, helfen die CSS-Klassen `.hidden-{screenklasse}` & `.visible-{screenklasse}-{displaytyp}` sie sind für die Screenklassen 's', 'm', 'l', 'xl' und die Displaytypen 'block', 'inline' und 'inline-block' verfügbar.
Die Klassen `.hidden-{screenklasse}` versteckt das Element nur in der angegeben Screenklasse!
Die Klassen `.visible-{screenklasse}-{displaytyp}` zeigt das Element nur in der angegeben Screenklasse!
Beide Klassen versteckten die Elemente auch vor Screen-Readern.

<div class="tc-example">
  <div class="table-responsive">
    <table class="visibility-example-table">

      <tr>
        <td>Sichtbar auf</td>
        <td class="text-center">
          <div class="hidden-xl visibility-example-item">X-Large</div>
          <div class="visible-xl-block visibility-example-item emphased">X-Large</div>
        </td>
        <td class="text-center">
          <div class="hidden-l visibility-example-item">Large</div>
          <div class="visible-l-block visibility-example-item emphased">Large</div>
        </td>
        <td class="text-center">
          <div class="hidden-m visibility-example-item">Medium</div>
          <div class="visible-m-block visibility-example-item emphased">Medium</div>
        </td>
        <td class="text-center">
          <div class="hidden-s visibility-example-item">Small</div>
          <div class="visible-s-block visibility-example-item emphased">Small</div>
        </td>
      </tr>

      <tr>
        <td>Kombiniert Sichtbar auf</td>
        <td class="text-center">
          <div class="hidden-xl hidden-s visibility-example-item">XL und S</div>
          <div class="visible-xl-block visible-s-block visibility-example-item emphased">XL und S</div>
        </td>
        <td class="text-center">
          <div class="hidden-l hidden-m visibility-example-item">L und M</div>
          <div class="visible-l-block visible-m-block visibility-example-item emphased">L und M</div>
        </td>
        <td class="text-center">
          <div class="hidden-xs hidden-m visibility-example-item">XS und M</div>
          <div class="visible-xs-block visible-m-block visibility-example-item emphased">XS und M</div>
        </td>
        <td class="text-center">
          <div class="hidden-xl hidden-l visibility-example-item">XL und L</div>
          <div class="visible-xl-block visible-l-block visibility-example-item emphased">XL und L</div>
        </td>
      </tr>

    </table>
  </div>
</div>


## Inhaltsseparatoren
Oft müssen Gruppen von Inhalten visuell separiert werden - hierzu bringen die Componenten Inhaltsseparatoren mit.
Sie beinflussen den horizontalen Abstand von Elementen in einer Spalte. Für elemente kann auch ein umschliesendes Div verwendet werden.
Separatoren werden von `6`-`18` Rastereinheiten angeboten:





<div class="tc-note">
**Anmerkung:**
Inhalte innerhalb des Inhaltsseparators werden unten ausgerichtet!
</div>

<div class="tc-example">
  <div style="border: 1px solid #eee;">
      <div class="cont-sep-8">
          <h1 class="underline">Separiert mit 8BU</h1>
      </div>
        <p>
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
        </p>
      <div class="cont-sep-6">
        <h1 class="underline">Separiert mit 6BU</h1>
      </div>
        <p>
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
        </p>

    </div>
</div>




```html
<div style="border: 1px solid #eee;">
  <div class="cont-sep-8">
    <h1 class="underline">Separiert mit 8BU</h1>
  </div>
  <p>
    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
  </p>
  <div class="cont-sep-6">
    <h1 class="underline">Separiert mit 6BU</h1>
  </div>
    <p>
      Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
    </p>
  </div>

```


## Abstandshelfer

Oft benötigen Elemente zusätzlichen Platz, um hervorgehoben oder eingepasst zu werden. Um im vorgegebenen Gestaltungsraster zu bleiben, bringen die Komponenten Abstandshelfer mit. Sie beeinflussen jeweils die `margin`-Eigenschaft des Elements, auf das sie angewendet werden. Die CSS-Klasse entscheidet, welches `margin`
mit welchem Wert beeinflusst wird `offset-{screenklasse}-{ausrichtung}-{rastereinheiten}`. Aktuell gibt es die Screenklassen 's', 'm', 'l', 'xl' und Ausrichtungen `top`, `right`, `bottom`, `left`. Es werden jeweils `1`-`10` Rastereinheiten angeboten:


<div class="tc-example">
  <div style="border: 1px solid #eee;">
    <div class="offset-left-5 offset-l-left-5 offset-m-left-10">5 Rastereinheiten nach rechts</div>
  </div>
</div>



```html
<div style="border: 1px solid #eee;">
  <div class="offset-left-5 offset-l-left-5 offset-m-left-10">5 Rastereinheiten nach rechts</div>
</div>
```

## Zentrierhelfer
Oft müssen Elemente in einer Spalte Zentriert werden - hierzu bringen die Componenten Zentrierhelfer mit.
Sie beinflussen die horizontale Ausrichtung von Elementen in einer Spalte. Hierfür wird jedoch ein umschliesendes Div benötigt.


<div class="tc-example">
  <div style="border: 1px solid #eee;">
    <div class="h-ctr">
		<button type="button" class="btn btn-default">Standard</button>
    </div>
  </div>
</div>



```html
<div style="border: 1px solid #eee;">
  <div class="h-ctr">
  	<button type="button" class="btn btn-default">Standard</button>
  </div>
</div>
```


<div class="tc-example">
  <div style="border: 1px solid #eee; height: 100px">
    <div class="h-ctr v-ctr">
    	<div>
			   <button type="button" class="btn btn-default">Standard</button>
		</div>
    </div>
  </div>
</div>


```html
<div style="border: 1px solid #eee; height: 100px">
  <div class="h-ctr v-ctr">
  	<div>
  		<button type="button" class="btn btn-default">Standard</button>
  	 </div>
  </div>
</div>
```


