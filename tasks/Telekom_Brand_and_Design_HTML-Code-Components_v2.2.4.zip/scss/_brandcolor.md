<h2 class="underline">Farben</h2>

## Hintergründe

Die Helfer-Klassen umfassen alle Markenfarben und dienen zur Einfärbung
von Element-Hintergründen. Sie beeinflussen somit die CSS-Eigenschaft
`background-color`:

###Telekom Magenta

<ul class="brandcolor-list">
  <li class="bg-brand"><span class="brandcolor-class">bg-brand</span></li>
</ul>

###Telekom Grau

<ul class="brandcolor-list">
  <li class="bg-gray-4"><span class="brandcolor-class">bg-gray-4</span></li>
  <li class="bg-gray-6"><span class="brandcolor-class">bg-gray-6</span></li>
  <li class="bg-gray-1"><span class="brandcolor-class text-white">bg-gray-1</span></li>
  <li class="bg-gray-2"><span class="brandcolor-class text-white">bg-gray-2</span></li>
  <li class="bg-gray-3"><span class="brandcolor-class text-white">bg-gray-3</span></li>
  <li class="bg-gray-5"><span class="brandcolor-class text-white">bg-gray-5</span></li>
  <li class="bg-gray-38"><span class="brandcolor-class text-white">bg-gray-38</span></li>
</ul>

###Screen Yellow

<ul class="brandcolor-list">
  <li class="bg-yellow"><span class="brandcolor-class">bg-yellow</span></li>
  <li class="bg-yellow-75"><span class="brandcolor-class">bg-yellow-75</span></li>
  <li class="bg-yellow-50"><span class="brandcolor-class">bg-yellow-50</span></li>
  <li class="bg-yellow-25"><span class="brandcolor-class">bg-yellow-25</span></li>
</ul>

###Screen Orange

<ul class="brandcolor-list">
  <li class="bg-orange"><span class="brandcolor-class">bg-orange</span></li>
  <li class="bg-orange-75"><span class="brandcolor-class">bg-orange-75</span></li>
  <li class="bg-orange-50"><span class="brandcolor-class">bg-orange-50</span></li>
  <li class="bg-orange-25"><span class="brandcolor-class">bg-orange-25</span></li>
</ul>

###Screen Violet

<ul class="brandcolor-list">
  <li class="bg-violet"><span class="brandcolor-class text-white">bg-violet</span></li>
  <li class="bg-violet-75"><span class="brandcolor-class text-white">bg-violet-75</span></li>
  <li class="bg-violet-50"><span class="brandcolor-class">bg-violet-50</span></li>
  <li class="bg-violet-25"><span class="brandcolor-class">bg-violet-25</span></li>
</ul>

###Screen Dark Blue

<ul class="brandcolor-list">
  <li class="bg-dark-blue"><span class="brandcolor-class text-white">bg-dark-blue</span></li>
  <li class="bg-dark-blue-75"><span class="brandcolor-class text-white">bg-dark-blue-75</span></li>
  <li class="bg-dark-blue-50"><span class="brandcolor-class">bg-dark-blue-50</span></li>
  <li class="bg-dark-blue-25"><span class="brandcolor-class">bg-dark-blue-25</span></li>
</ul>

###Screen Light Blue

<ul class="brandcolor-list">
  <li class="bg-light-blue"><span class="brandcolor-class">bg-light-blue</span></li>
  <li class="bg-light-blue-75"><span class="brandcolor-class">bg-light-blue-75</span></li>
  <li class="bg-light-blue-50"><span class="brandcolor-class">bg-light-blue-50</span></li>
  <li class="bg-light-blue-25"><span class="brandcolor-class">bg-light-blue-25</span></li>
</ul>

###Screen Petrol

<ul class="brandcolor-list">
  <li class="bg-petrol"><span class="brandcolor-class">bg-petrol</span></li>
  <li class="bg-petrol-75"><span class="brandcolor-class">bg-petrol-75</span></li>
  <li class="bg-petrol-50"><span class="brandcolor-class">bg-petrol-50</span></li>
  <li class="bg-petrol-25"><span class="brandcolor-class">bg-petrol-25</span></li>
</ul>

###Screen Green

<ul class="brandcolor-list">
  <li class="bg-green"><span class="brandcolor-class">bg-green</span></li>
  <li class="bg-green-75"><span class="brandcolor-class">bg-green-75</span></li>
  <li class="bg-green-50"><span class="brandcolor-class">bg-green-50</span></li>
  <li class="bg-green-25"><span class="brandcolor-class">bg-green-25</span></li>
</ul>

```html
<div class="bg-yellow"></div>
```