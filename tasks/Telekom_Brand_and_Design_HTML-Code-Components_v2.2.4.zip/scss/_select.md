# Select

<div class="tc-example" role="application">
  <form>
    <fieldset class="form-fieldset">
      <legend>Gruppen Beschriftung</legend>
      <div class="form-input-set">
        <label for="selectbox" title="Primäroptionen Auswahlliste">Selectbox</label>
        <select name="select" id="selectbox" class="form-select">
          <option value="opt1">Option A</option>
          <option value="opt2" selected>Option B</option>
          <option value="opt3">Option C</option>
          <option value="opt4" disabled>Option D (inaktiv)</option>
        </select>
      </div>
      <div class="form-input-set">
        <label for="selectbox2" title="Sekundäroptionen Auswahlliste">Selectbox ( inaktiv )</label>
        <select name="select2" id="selectbox2" class="form-select" disabled>
          <option value="opt1">Option A</option>
          <option value="opt2">Option B</option>
          <option value="opt3">Option C</option>
          <option value="opt4" disabled>Option D (inaktiv)</option>
        </select>
      </div>
    </fieldset>
    <button type="submit" class="sr-only">senden</button>
  </form>
</div>

```html
<!-- Selectbox -->
<div class="form-input-set">
  <label for="selectbox" title="Primäroptionen Auswahlliste">Selectbox</label>
  <select name="select" id="selectbox" class="form-select">
    <option value="opt1">Option A</option>
    <option value="opt2" selected>Option B</option>
    <option value="opt3">Option C</option>
    <option value="opt4" disabled>Option D (inaktiv)</option>
  </select>
</div>

<!-- Selectbox (inaktiv) -->
<div class="form-input-set">
  <label for="selectbox2" title="Sekundäroptionen Auswahlliste">Selectbox ( inaktiv )</label>
  <select name="select2" id="selectbox2" class="form-select" disabled>
    <option value="opt1">Option eins</option>
    <option value="opt2">Option zwei</option>
    <option value="opt3">Option drei</option>
    <option value="opt4" disabled>Option vier (inaktiv)</option>
  </select>
</div>
```

Nähere Informationen zu Accessibility von Eingabe-Elementen im Artikel:
[SEO und Accessibility](accessibility.html#aria)