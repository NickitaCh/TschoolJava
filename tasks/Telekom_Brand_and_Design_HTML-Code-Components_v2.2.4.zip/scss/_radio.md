# Radio

Da Radiobuttons meist in Gruppen auftreten sollten diese nur innerhalb eines `<fieldset>`  vorkommen um so deren Zusammengehörigkeit zu visualisieren. Der `<legend>`-Tag beinhaltet dabei die Beschreibung der Gruppe.
 
Ein einzelener Radio-Button wird mit dem `<input type="radio">`-Tag erzeugt. Die CSS-Klasse `.form-radio` verleiht ihm das Grundgerüst und die grundelegenden Eigenschaften die alle Browser gemeinsam abbilden können.

Für eine optimale Darstellung gibt es auch für Radiobuttons ein jQuery-Plugin:

```javascript
$('.form-radio').radio()
```

<div class="tc-example" role="application">
  <fieldset class="form-fieldset">
    <legend>Gruppen Beschriftung</legend>
      <div class="form-radio-set">
        <label>
          <input type="radio" name="rb" value="rb1" class="form-radio">foo
        </label>
      </div>
      <div class="form-radio-set">
        <label>
          <input type="radio" name="rb" value="rb2" class="form-radio" checked>bar
        </label>
      </div>
      <div class="form-radio-set">
        <label>
          <input type="radio" name="rb" value="rb3" class="form-radio" disabled>Inaktiv
        </label>
      </div>
  </fieldset>
</div>

```html
<fieldset class="form-fieldset">
  <legend>Gruppen Beschriftung</legend>
    <div class="form-radio-set">
      <label>
        <input type="radio" name="rb" value="rb1" class="form-radio">foo
      </label>
    </div>
    <div class="form-radio-set">
      <label>
        <input type="radio" name="rb" value="rb2" class="form-radio" checked>bar
      </label>
    </div>
    <div class="form-radio-set">
      <label>
        <input type="radio" name="rb" value="rb3" class="form-radio" disabled>Inaktiv
      </label>
    </div>
</fieldset>
```