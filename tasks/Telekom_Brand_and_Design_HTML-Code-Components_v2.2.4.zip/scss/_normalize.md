## Normalisierung
Um eine einheitlichere Darstellung auf verschiedenen Browsern zu erzielen
wird [normalize.css] eingesetzt. [normalize.css] ist ein Projekt von
[Nicolas Gallagher].

[normalize.css]: http://necolas.github.io/normalize.css/
[Nicolas Gallagher]: http://nicolasgallagher.com/