<!--
//
//
// SEO und Accessibility
-->

Webinhalte und Web-Applikationen bedürfen immer einer besonderen Aufbereitung
der Inhalte. Die Lesbarkeit ist ein maßgebliches Kriterium für die Qualität
einer Webseite wobei sowohl auf Maschinen wie Menschen eigens Rücksicht
genommen werden muss. Während Nutzer aufgrund der Gestaltung und
Zusammenhänge problemlos Rückschlüsse zeihen können muss der Inhalt
für Suchmaschinen gesondert aufbereitet werden. Ähnlich wenngleich
wesentlich vielseitiger verhält es sich mit den Problemen denen Menschen
mit körperlichen Einschränkungen gegenüberstehen. Eine Ergänzung von
beschreibenden Texten für Sehbehinderte (insbesondere auch für dynamische
Inhalte bei AJAX-Seiten!) ist genauso unumgänglich wie die Gewährleistung
von Navigationsmöglichkeiten mittels Tastatur.

Als nützliche Hilfe haben sich hierfür ARIA und Rich Snippets
herauskristallisiert. Im Folgenden versuchen wir einen kurzen
Überblick über beide Erweiterungen des Markups zu liefern und
Ihnen den Einstieg zu erleichtern.

<h2 id="aria" class="underline">Aria</h2>

Accessible Rich Internet Applications (ARIA) ist eine Sammlung von speziellen
Attributen, mit deren Hilfe es möglich ist Webinhalte für Menschen mit
körperlichen Einschränkungen leichter zugänglich oder besser verständlich
zu machen.

ARIA ist bei den meisten Browsern und Screen-Readern implementiert,
aber der Umfang kann bei älteren Versionen stark eingeschränkt sein.
Daher empfiehlt es sich sogenanntes „sicheres“ ARIA zu verwenden, um
Probleme oder störende Update-Hinweise zu vermeiden.

Zu beachten ist darüber hinaus, dass selbst erstellte Komponenten
mit der Tastatur zugänglich sein müssen; traditionell über Tab, Space,
Enter, Pfeil-Tasten, Shift und Escape.

### Die Problematik am Beispiel

Das einfachste Beispiel wäre ein Knopf zum Speichern. Solche
Buttons werden heute oftmals fälschlier Weise mit `<a>` oder `<div>`-Tags
erstellt und erhalten mit JavaScript ihre eigentliche Funktion.
Wie schnell dies für einen Blinden zu Falle werden kann, sollen
die folgenden Beispiele aufzeigen.

**Negativbeispiel**
```html
<div class="button" onclick="save()">speichern</div>
```
Mag sein, dass der „Button“ wie ein Button aussieht, dies ist für
Screen-Reader jedoch weder ersichtlich noch ist er mit der Tastatur
überhaupt zu erreichen oder zu bedienen.

**Negativbeispiel**
```html
<div class="button" onclick="save()" tabindex="0">speichern</div>
```
Der tabindex bewirkt zwar, dass das Element angesprungen werden kann,
es ist jedoch weiterhin nicht möglich ihn mittels Space/Enter zu bedienen.

**Negativbeispiel**
```html
<div class="button" onclick="save()" onkeydown="save()" tabindex="0">speichern</div>
```
Sie denken Sie haben an alles gedacht? Einfach die selbe Funktion für
die Tastatur hinzufügen und schon ist alles OK? Ganz so einfach ist das
nicht, denn allein das Überspringen mit dem Tabulator führt ohne weitere
Abfrage nun zum Speichern.

**Negativbeispiel**
```html
<a href="javascript:save()">speichern</div>
```
Ein link ist mit Tastatur zu erreichen und auch bedienbar (zumindest mit
Enter), vermittelt dem Screen-Reader jedoch weiterhin den Eindruck, dass
es sich um eine Verknüpfung handelt, sprich die Seite verlassen wird, auch
wenn dies nicht der Fall ist.

**Negativbeispiel**
```html
<a href="#" onclick="save(event)" onkeydown="save(event)">speichern</div>
```
Um auch die Space-Taste zum Speichern nutzen zu können, wie bei einem
gewöhnlichen Button auch hier noch einmal mit onkeydown. Da wir die Seite
nicht verlassen wollten enthält unsere save-Funktion einen Aufruf von
event.preventDefault() ... Sie haben eben einen Blinden eingesperrt –
denn dieser link kann ohne Maus oder weitere Abfrage niemals mehr verlassen werden.

**Korrekt**
```html
<button onclick="save(event)" class="button">speichern</button>
```
Solange es korrektes Markup gibt, ist dies der einzig richtige Weg.

### Beispiele

Die vorangegangenen Beispiele lassen sich natürlich lösen.
Allerdings vermitteln sie dennoch gut, welcher Aufwand und wie viel Umsicht
nötig ist, um selbst einfachste Imitate bestehender Komponenten so zu
realisieren, dass sie wie gewohnt funktionieren. Geht es nun um Komponenten,
die sich anders nicht umsetzen lassen – sei es weil diese bisher nicht
existieren oder styling-Mittel nicht ausreichen – kommt ARIA ins Spiel.

<div class="tc-example">
  <div class="form-checkbox-set">
    <label>
      <input type="checkbox" name="cb" value="val1" class="form-checkbox">Checkbox
    </label>
  </div>
</div>

```html
<div class="form-checkbox-set">
  <label>
    <input type="checkbox" name="cb" value="val1" class="form-checkbox">Checkbox
  </label>
</div>
```

Durch hinzufügen eines *role*-Attributes kann dem Screen-Reader mitgeteilt
werden, um was für ein Element es sich handeln soll:

```html
<div class="form-checkbox-set">
  <label>
    <button type="button" role="checkbox" class="form-checkbox-js" aria-checked="false">
      <span class="check"></span>
    </button>
    <input type="checkbox" name="cb" value="val1" class="form-checkbox hidden">Checkbox
  </label>
</div>
```

Nähere Informationen zu diesem Thema und weitere Beispiele finden Sie
u. A. auf (https://developer.mozilla.org/de/docs/Barrierefreiheit/ARIA)

<h2 id="rich-snippets" class="underline">Rich Snippets</h2>

Bei Snippets handelt es sich um die Kurzinformationen, die unter Ergebnissen
von Suchmaschinen angezeigt werden. Sie sollen Internetnutzern auf den
ersten Blick vermitteln, warum die Informationen auf der vorgeschlagenen
Seite relevant sind. Es kann sich je nach Seite dabei um Adressen,
Öffnungszeiten, Erfahrungsberichte, Preise, Produkte, Hörproben und
vieles weitere handeln.

Im allgemeinen spricht man hierbei von _Rich Snippets_, welche
den Inhalt soweit aufbereiten, dass er maschinen-lesbar ist.
Unterteilt werden sie aktuell in drei verschiedene Standards:

* Mikrodaten
* Mikroformate
* RDFs

Wir empfehlen die Anwendung von Mikrodaten und haben diese daher bereits
in die vorliegenden Beispiele integriert. Mikrodaten werden von Google,
Microsoft, Yahoo! und Yandex gemeinsam weiterentwickelt und von den
gängigen Suchmaschinen unterstützt.

### Beispiel Mikrodaten

Zum besseren Verständnis betrachten wir ein konkretes Beispiel für Mikrodaten.
Hierzu bedienen wir uns der Einfachheit halber eines Preisangebots.

```html
<div>
    <span>4,<sup>95</sup> €</span>
    <a href="http://www.example.com/images/309433">Bilder</a>
    <a href="http://www.example.com/purchase/309433">Jetzt bestellen</a>
</div>
```

Die Problematik liegt auf der Hand. Unser Angebot besteht aus mehreren
Teilen: den Euro, ein hochgestellter Cent-Betrag, dem Währungssymbol und diversen
Links. Um Suchmaschinen eindeutige Hinweise liefern zu können wie die
einzelnen Bestandteile zu interpretieren sind, erklären wir das Element
zunächst zu einem **Bereich** für Mikrodaten, indem wir es um
das *itemscope-Attribut* erweitern.

```html
<div itemscope>
    <span>4,<sup>95</sup> €</span>
    <a href="http://www.example.com/images/309433">Bilder</a>
    <a href="http://www.example.com/purchase/309433">Jetzt bestellen</a>
</div>
```

Das es sich allerdings tatsächlich um ein Produktangebot
handelt und nicht um einen Betrag in einem fortlaufenden Text wie einem
Zeitungsartikel oder sogar etwas komplett anderes, ist jedoch noch nicht
ersichtlich. Dies spezifizieren wir durch die Angabe eines **Typs**
mithilfe des *itemtype*.

```html
<div itemscope itemtype="http://schema.org/Offer">
    <span>4,<sup>95</sup> €</span>
    <a href="http://www.example.com/images/309433">Bilder</a>
    <a href="http://www.example.com/purchase/309433">Jetzt bestellen</a>
</div>
```

Das es sich um ein Angebot handelt wäre damit geklärt, aber darüber
hinaus muss die Bedeutung der einzelnen Elemente geklärt werden. Dies
geschieht durch Zuordnung der entsprechenden **Eigenschaften** mit dem
*itemprop* Attribut.

```html
<div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
    <span itemprop="price">4,<sup>95</sup> €</span>
    <a itemprop="image" href="http://www.example.com/images/309433">Bilder</a>
    <a itemprop="url" href="http://www.example.com/purchase/309433">Jetzt bestellen</a>
</div>
```

Letztendlich lässt sich der Preis noch eindeutiger definieren,
indem wir uns meta-tags bedienen. Dies ermöglicht eine für Maschinen
eindeutige Preisangabe (ohne lokale Tausender-/Dezimaltrennzeichen)
und kann insbesondere bei unterschiedlichen Währungen wie $/£ hilfreich sein,
welche das selbe Währungssymbol haben.

```html
<div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
    <meta itemprop="priceCurrency" content="EUR">
    <meta itemprop="price" content="4.95">
    <span>4,<sup>95</sup> €</span>
    <a itemprop="image" href="http://www.example.com/images/309433">Bilder</a>
    <a itemprop="url" href="http://www.example.com/purchase/309433">Jetzt bestellen</a>
</div>
```

Nähere Informationen zu diesem Thema und weitere
Beispiele finden Sie auf (http://schema.org/docs/gs.html)