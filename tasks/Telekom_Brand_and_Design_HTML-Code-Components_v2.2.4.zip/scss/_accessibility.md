## Screenreader-Helfer

Die CSS-Klasse `.sr-only` versteckt Elemente visuell.
Sorgt aber dafür, dass der Inhalt von Screenreadern erkannt wird.
Sie sollte überall da zum tragen kommen, an dem Screenreader das eigentliche
Element nicht erkennen und interpretieren können.
Ein klassisches Beispiel stellt ein einfaches Icon dar:

<div class="tc-example">
  <span class="sr-only">Synchronisieren</span>
  <i class="icon icon-synchronize" aria-hidden="true"></i>
</div>

```html
  <span class="sr-only">Synchronisieren</span>
  <i class="icon icon-synchronize" aria-hidden="true"></i>
```