<!--
//
//
// Badges
-->

Um Einträge und deren Gewichtung hervorzuheben können sog. Badges
eingesetzt werden.

Badges `.badge` werden in der Regel auf das HTML-Tag `<span>` angewendet:

<div class="tc-example">
<a href="#">Neue Nachrichten <span class="badge">14</span></a>
</div>

```html
<a href="#">Neue Nachrichten <span class="badge">14</span></a>
```

## Brand-Variante

<div class="tc-example">
    <p><span class="badge">34</span> - Regular</p>
    <p><span class="badge badge-brand">34</span> - Brand</p>
</div>

```html
<!-- Regular -->
<span class="badge">34</span>
<!-- Brand -->
<span class="badge badge-brand">34</span>
```

<div class="tc-note">
**Anmerkung Barrierefreiheit:**
Die eingesetzten Farben haben meist eine Bedeutung. Um diese Bedeutung auch
beim Einsatz von Unterstützungstechnologien zu untermauern sollte sie
zusätzlich versteck in Textform durch die CSS-Klasse `.sr-only´ hinterlegt werden.
</div>