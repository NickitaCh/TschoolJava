<!--
//
//
// Buttons
-->

Zur Erstellung von Buttons bietet HTML eine Vielzahl von Möglichkeiten.
Buttons sollten je nach Einsatzzweck durch die Tags
`<button>`, `<input type="submit">` oder `<input type="reset">` erzeugt werden.
Die CSS-Klasse `.btn` sorgt anschließend für das Grundgerüst.
Über eine zweite CSS-Klasse wird dann das Aussehen des Buttons bestimmt.

Je nach Einsatzgebiet stehen auch hier unterschiedliche Farben für verschiedene
Bedeutungen bereit. Soll ein Button inaktiv geschaltet werden, wird das
Attribut `disabled` angewendet:

<div class="tc-example">
  <button type="button" class="btn btn-default">Standard</button>
  <button type="button" class="btn btn-brand">Marke</button>
  <button type="button" class="btn btn-default" disabled>Inaktiv</button>
  <button type="button" class="btn btn-clean">Clean</button>
</div>

```html
<!-- Standard Button -->
<button type="button" class="btn btn-default">Standard</button>

<!-- Marke Button -->
<button type="button" class="btn btn-brand">Marke</button>

<!-- Inaktiv Button -->
<button type="button" class="btn btn-clean">Inaktiv</button>

<!-- Inaktiv Button -->
<button type="button" class="btn btn-default" disabled>Inaktiv</button>
```

<div class="tc-note tc-note-warning">
**Achtung:**
Die CSS-Klasse `.btn` darf nie alleine stehen.
</div>

<div class="tc-note">
**Anmerkung:**
Das Anwenden der CSS-Klasse `.btn` auf einen `<a>` Link ist zwar möglich,
sollte  aufgrund der Konsistenz jedoch vermieden werden. Falls dies nicht möglich ist, muss das `<a>`-Tag mit dem Attribut
`role="button"` versehen werden.
</div>

<div class="tc-note tc-note-info">
**Tipp:**
Das Button-Verhalten kann auf viele Elemente angewendet werden.
So natürlich auch auf die unterschiedlichen Button-Typen wie
`type="submit"` oder `type="reset"`.
</div>

<div class="tc-example">
  <button type="submit" class="btn btn-default">Absenden</button>
  <button type="reset" class="btn btn-default">Zurücksetzen</button>
</div>

```html
<!-- Absenden Button -->
<button type="submit" class="btn btn-default">Absenden</button>

<!-- Zurücksetzen Button -->
<button type="reset" class="btn btn-default">Zurücksetzen</button>
```

<div class="tc-note">
**Anmerkung:**
Der grüne und rote Button werden primär für die Kernfunktionalitäten „Anrufen“ bzw. „Anruf beenden“ verwendet.
</div>

<div class="tc-example">
  <button type="button" class="btn btn-positive">Anrufen</button>
  <button type="button" class="btn btn-negative">Anruf beenden</button>
</div>

```html
<!-- Anrufen Button -->
<button type="button" class="btn btn-positive">Anrufen</button>

<!-- Anruf beenden Button -->
<button type="button" class="btn btn-negative">Anruf beenden</button>
```


## Größen

Für Buttons stehen drei verschiedene Größen zur Verfügung.
Die CSS-Klasse `.btn-small` lässt den Button kleiner,
die CSS-Klasse `.btn-large` größer erscheinen:

<div class="tc-example">
  <button type="button" class="btn btn-default btn-small">Klein</button>
  <button type="button" class="btn btn-default">Normal</button>
  <button type="button" class="btn btn-default btn-large">Groß</button>
</div>

```html
<button type="button" class="btn btn-default btn-small">Klein</button>
<button type="button" class="btn btn-default">Normal</button>
<button type="button" class="btn btn-default btn-large">Groß</button>
```

## Breiten

Je nach Layout kann es sinnvoll sein, Buttons schmal oder extrem weit darzustellen. Hierfür sind die CSS-Klassen `.btn-minimal` und `.btn-block` vorgesehen.

Ein Button mit der Klasse `.btn-block` passt sich zu 100% in sein Elternelement ein:

<div class="tc-example">
  <button type="button" class="btn btn-default btn-minimal">Minimal</button>
  <button type="button" class="btn btn-default">Normal</button><br>
  <br>
  <button type="button" class="btn btn-default btn-block">Block</button>
</div>

```html
<button type="button" class="btn btn-default btn-minimal">Minimal</button>
<button type="button" class="btn btn-default">Normal</button>
<button type="button" class="btn btn-default btn-block">Block</button>
```

## Icon Buttons

Für Buttons, die nur ein Icon enthalten, ist die CSS-Klasse
`.btn-icon` vorgesehen. Sie lässt den Button schmaler erscheinen. Buttons, die aus Icon und Text bestehen, benötigen __keine__ zusätzliche Auszeichnung:

<div class="tc-example">
  <button class="btn btn-default btn-icon" title="Synchronisieren">
    <i class="icon icon-synchronize" aria-hidden="true"></i>
  </button>
  <button class="btn btn-default">
    <i class="icon icon-synchronize" aria-hidden="true"></i>Synchronisieren
  </button>
  <button class="btn btn-default">
    Synchronisieren<i class="icon icon-right icon-synchronize" aria-hidden="true"></i>
  </button>
</div>

```html
<!-- Icon-Button - benötigt unbedingt ein Title-Attribut -->
<button class="btn btn-default btn-icon" title="Synchronisieren">
  <i class="icon icon-synchronize" aria-hidden="true"></i>
</button>
<button class="btn btn-default">
  <i class="icon icon-synchronize" aria-hidden="true"></i>Synchronisieren
</button>
<button class="btn btn-default">
  Synchronisieren<i class="icon icon-right icon-synchronize" aria-hidden="true"></i>
</button>
```

<div class="tc-note">
**Anmerkung Barrierefreiheit:**
Da das Icon des Icon-Buttons mit dem `aria-hidden`-Attribute vor
Unterstützungstechnologien versteckt wird sollte der Button dringen
durch das Anwenden des `title`-Attributes beschrieben werden.
</div>

<h2>Button-Sectioned</h2>

Buttons und Pager lassen sich mit Hilfe der CSS-Klasse `btn-sectioned` zu einer Leiste von
Benutzerelementen zusammenfassen.

<div class="tc-example">
    <div class="row">
        <div class="col-l-12">
            <div class="btn-sectioned">
                <button class="btn btn-default">Regular</button>
                <button class="btn btn-default">Regular</button>
                <button class="btn btn-default">Regular</button>
            </div>
<br>&nbsp;
        </div>
        <div class="col-l-12">
            <div class="btn-sectioned">
                <button class="btn btn-default btn-icon" title="Anhänge"><i class="icon icon-attachment" aria-hidden="true"></i></button>
                <button class="btn btn-default btn-icon" title="Einstellungen"><i class="icon icon-settings" aria-hidden="true"></i></button>
                <button class="btn btn-default btn-icon" title="Kontextmenü"><i class="icon icon-context-menu" aria-hidden="true"></i></button>
            </div>
<br>&nbsp;
        </div>
        <div class="col-l-12">
            <div class="btn-sectioned">
                <button class="btn btn-default" title="Anhänge"><i class="icon icon-attachment" aria-hidden="true"></i>Icon</button>
                <button class="btn btn-default" title="Einstellungen"><i class="icon icon-settings" aria-hidden="true"></i>Icon</button>
                <button class="btn btn-default" title="Kontextmenü"><i class="icon icon-context-menu" aria-hidden="true"></i>Icon</button>
            </div>
        </div>
    </div>
</div>

```html
<div class="btn-sectioned">
    <button class="btn btn-default">Regular</button>
    <button class="btn btn-default">Regular</button>
    <button class="btn btn-default">Regular</button>
</div>

...

<div class="btn-sectioned">
    <button class="btn btn-default" title="Anhänge"><i class="icon icon-attachment" aria-hidden="true"></i>Icon</button>
    <button class="btn btn-default" title="Einstellungen"><i class="icon icon-settings" aria-hidden="true"></i>Icon</button>
    <button class="btn btn-default" title="Kontextmenü"><i class="icon icon-context-menu" aria-hidden="true"></i>Icon</button>
</div>

...

<div class="btn-sectioned">
    <button class="btn btn-default"><i class="icon icon-attachment" aria-hidden="true"></i>Icon</button>
    <button class="btn btn-default"><i class="icon icon-bookmark" aria-hidden="true"></i>Icon</button>
    <button class="btn btn-default"><i class="icon icon-context-menu" aria-hidden="true"></i>Icon</button>
</div>
```