<!--
//
//
// Benachrichtigungen
-->

In Anwenungen sind Rückmeldungen an einen Benutzer unerlässlich.
Zur Erstellung solcher Benachrichtigungen steht die CSS-Klasse `.notification`
zur Verfügung. Die Nachricht sollte dabei in den Container
`.notification-content` geschrieben werden. Überschriften haben
die CSS-Klasse `.notification-heading`:

<div class="tc-example">
    <div class="notification">
        <div class="notification-content">
            <div class="notification-heading">Regular</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
</div>

```html
<div class="notification">
    <div class="notification-content">
        <div class="notification-heading">Regular</div>
        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
    </div>
</div>
```

## Funktionale Dekorationen

Um die Bedeutungen von Benachrichtigungen zu unterstützen
stehen verschiedene Farb-Varianten zur Verfügung:

<div class="tc-example">
    <div class="notification notification-positive">
        <div class="notification-content">
            <div class="notification-heading">Positive</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
    <div class="notification notification-warning">
        <div class="notification-content">
            <div class="notification-heading">Warning</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
    <div class="notification notification-negative">
        <div class="notification-content">
            <div class="notification-heading">Negative</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
</div>

```html
<div class="notification notification-positive">...</div>
<div class="notification notification-warning">...</div>
<div class="notification notification-negative">...</div>
```

## Overlay Dekoration

Werden Benachrichtigungen über anderem Inhalt angezeigt sollte dies auch
visuell vermittelt werden. Hierfür ist die CSS-Klasse `.notification-overlay`
zuständig:

<div class="tc-example">
    <div class="notification notification-overlay">
        <div class="notification-content">
            <div class="notification-heading">Overlay</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
</div>

```html
<div class="notification">
    <div class="notification-content notification-overlay">
        <div class="notification-heading">Overlay</div>
        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
    </div>
</div>
```

## Zusätzlicher Inhalt

Um den Inhalt einer Benachrichtigungen nochmals zu verdeutlichen kann
zusätzlicher Inhalt in Form eines Icons oder eines Bildes in die
Benachrichtigung integriert werden. Der zusätzliche Inhalt kann mit der
CSS-Klasse `.notification-left` vor und mit der CSS-Klasse `.notification-right`
hinter dem Inhalt platziert werden:

<div class="tc-example">
    <div class="notification">
        <div class="notification-left">
            <div class="icon-frame"><i class="icon icon-comment icon-large"></i></div>
        </div>
        <div class="notification-content">
            <div class="notification-heading">Icon</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
    <div class="notification">
        <div class="notification-left">
            <div class="img-frame"><img class="img-thumbnail" src="assets/play.jpg" alt="spielende Kinder"/></div>
        </div>
        <div class="notification-content">
            <div class="notification-heading">Image</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
</div>

```html
<!-- Icon -->
<div class="notification">
    <div class="notification-left">
        <div class="icon-frame"><i class="icon icon-comment icon-large"></i></div>
    </div>
    <div class="notification-content">
      ...
    </div>
</div>

<!-- Bild -->
<div class="notification">
    <div class="notification-left">
        <div class="img-frame"><img class="img-thumbnail" src="assets/play.jpg" alt="spielende Kinder"/></div>
    </div>
    <div class="notification-content">
      ...
    </div>
</div>
```

<div class="tc-note">
**Anmerkung:**
Besondere Beachtung sollte dabei den CSS-Klassen `.icon-frame` und
`.img-frame` geschenkt werden in denen jeweils kein Zeilenumbruch
und Leerzeichen enthalten sein sollten
</div>

## Schließbare Benachrichtigungen

Die Schließen-Funktion benötigt das JavaScript `notification`-Plugin.

<div class="tc-example">
    <div class="notification notification-dismissible fade in">
        <button type="button" class="close" data-dismiss="notification">
            <span aria-hidden="true">x</span>
            <span class="sr-only">Schließen</span>
        </button>
        <div class="notification-content">
            <div class="notification-heading">Schließen</div>
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
        </div>
    </div>
</div>

### Verwendung

Zunächst wird natürlich ein Schließen-Button benötigt. Hierfür sollte
das Mikro-Modul `.close` verwendet werden.
Über das Attribut `data-dismiss="notification"` wird die Schließen-Funktionalität
aktiviert:

```html
<div class="notification notification-dismissible">
    <button type="button" class="close" data-dismiss="notification">
        <span aria-hidden="true">x</span>
        <span class="sr-only">Schließen</span>
    </button>
    <div class="notification-content">
        <div class="notification-heading">Schließen</div>
        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.
    </div>
</div>
```

Um das Schließen zu Animieren müssen die CSS-Klassen `.fade` und `.in` bereits
auf die Benachrichtigung angewendet sein.

**Methoden**

Schließen einer Benachrichtigung
```js
$().notification('close')
```
Die Benachrichtigung wird komplett aus dem DOM entfernt.

<table class="table table-small">
  <caption>Events</caption>
  <thead>
    <tr>
      <th>Typ</th>
      <th>Beschreibung</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>close.tc.modal</td>
      <td>Dieses Event tritt noch vor dem eigentlichen Schließen des Modal-Dialogs auf.</td>
    </tr>
    <tr>
      <td>closed.tc.modal</td>
      <td>Dieses Event tritt auf, wenn der Modal-Dialog fertig geschlossen wurde.</td>
    </tr>
  </tbody>
</table>