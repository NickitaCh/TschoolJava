<!--
//
//
// Breadcrumb
-->

Breadcrumbs sollen dem Benutzer veranschaulichen wo er sich derzeit
innerhalb der Seite aufhält.
Die CSS-Klasse `.breadcrumb` sorgt dabei für die nötige Formatierung
und fügt auch die Trennzeichen ein:

<div class="tc-example" lang="en">
  <span class="sr-only">You are here:</span>
  <ol class="breadcrumb">
      <li class="active">Home</li>
  </ol>

  <span class="sr-only">You are here:</span>
  <ol class="breadcrumb">
      <li><a href="javascript: void(0);">Home</a></li>
      <li class="active">Library</li>
  </ol>

  <span class="sr-only">You are here:</span>
  <ol class="breadcrumb">
      <li><a href="javascript: void(0);">Home</a></li>
      <li><a href="javascript: void(0);">Library</a></li>
      <li class="active">Site</li>
  </ol>
</div>

```html
<span class="sr-only">You are here:</span>
<ol class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li><a href="#">Library</a></li>
    <li class="active">Site</li>
</ol>
```