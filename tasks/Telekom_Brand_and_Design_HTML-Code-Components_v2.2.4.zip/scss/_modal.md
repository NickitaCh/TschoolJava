<!--
//
//
// Modal
-->

### Aufbau des Dialogs

<div class="tc-example">
  <div class="modal fade in" aria-labelledby="exampleModalLabel" aria-hidden="true" role="dialog" style="display: block; position: inherit; z-index: 0;">
      <div class="modal-dialog">
          <div class="modal-content">
              <button type="button" class="close" data-dismiss="modal">
                <span aria-hidden="true">x</span>
                <span class="sr-only">Close</span>
              </button>
              <div class="modal-header">
                  <h4 class="modal-title" id="exampleModalLabel">Headline</h4>
              </div>
              <div class="modal-body">
                  <p>Content...</p>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
                  <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
              </div>
          </div>
      </div>
  </div>
</div>

```html
<div class="modal fade" aria-labelledby="exampleModalLabel"
     aria-hidden="true" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal">
              <span aria-hidden="true">x</span>
              <span class="sr-only">Close</span>
            </button>
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Headline</h4>
            </div>
            <div class="modal-body">
                <p>Content...</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">Schließen</button>
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>
```

### Initialisierung des Dialogs

<div class="tc-example">
  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-init-demo">Modal-Dialog öffnen</button>

  <div id="modal-init-demo" class="modal fade" aria-labelledby="exampleModalLabel2" aria-hidden="true" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">x</span>
          <span class="sr-only">Close</span>
        </button>
        <div class="modal-header">
          <h4 class="modal-title" id="exampleModalLabel2">Headline</h4>
        </div>
        <div class="modal-body">
          <p>Content...</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
        </div>
      </div>
    </div>
  </div>
</div>

```html
<!-- Der Button öffnet den Modal-Dialog -->
<button type="button" class="btn btn-default" data-toggle="modal"
        data-target="#modal-init-demo">Modal-Dialog öffnen</button>

<!-- Der Modal-Dialog -->
<div class="modal fade" aria-labelledby="exampleModalLabel"
     aria-hidden="true" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal">
              <span aria-hidden="true">x</span>
              <span class="sr-only">Close</span>
            </button>
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Headline</h4>
            </div>
            <div class="modal-body">
                <p>Content...</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">Schließen</button>
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>
```

### Datenmanagement

Oft sollen Daten im Modal-Dialog von außen beeinflussbar sein,
beispielsweise wenn ein Formular im Dialog vorausgefüllt werden soll.

In einem zweiten Schritt sollen beim Absenden des Formulars die Daten
verarbeitet werden können.

Das folgende Beispiel zeigt diese Fälle:

<div class="tc-example">

  <button type="button" class="btn btn-default" data-toggle="modal" data-init-value="1" data-target="#modal-init-demo2">Modal-Dialog mit &lt;1&gt; öffnen</button>
  <button type="button" class="btn btn-default" data-toggle="modal" data-init-value="2" data-target="#modal-init-demo2">Modal-Dialog mit &lt;2&gt; öffnen</button>

  <div id="modal-init-demo2" class="modal fade" aria-labelledby="exampleModalLabel3" aria-hidden="true" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <form name="exampleModalForm3">
          <button type="button" class="close" data-dismiss="modal">
            <span aria-hidden="true">x</span>
            <span class="sr-only">Close</span>
          </button>
          <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel3">Headline</h4>
          </div>
          <div class="modal-body">
            <div class="form-input-set">
              <label for="text-modal">Value</label>
              <input type="text" class="form-input" name="text-modal" id="text-modal">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
            <button type="submit" class="btn btn-default">Senden</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

```html
<!-- Der Button öffnet den Modal-Dialog -->
<button type="button" class="btn btn-default" data-toggle="modal" data-init-value="1"
  data-target="#modal-init-demo2">Modal-Dialog mit &lt;1&gt; öffnen</button>
<button type="button" class="btn btn-default" data-toggle="modal" data-init-value="2"
  data-target="#modal-init-demo2">Modal-Dialog mit &lt;2&gt; öffnen</button>

<!-- Der Modal-Dialog -->
<div id="modal-init-demo2" class="modal fade"
     aria-labelledby="exampleModalLabel3" aria-hidden="true" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <form name="exampleModalForm3">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">x</span>
          <span class="sr-only">Close</span>
        </button>
        <div class="modal-header">
          <h4 class="modal-title" id="exampleModalLabel3">Headline</h4>
        </div>
        <div class="modal-body">
          <div class="form-input-set">
            <label for="text-modal">Value</label>
            <input type="text" class="form-input"
                   name="text-modal" id="text-modal">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default"
                  data-dismiss="modal">Schließen</button>
          <button type="submit" class="btn btn-default">Senden</button>
        </div>
      </form>
    </div>
  </div>
</div>
```

JavaScript:
```javascript
// Daten übermitteln
$('#modal-init-demo2').on('show.tc.modal', function (event) {
  var $button = $(event.relatedTarget) // der betätigte Button
  var value = $button.data('init-value') // Wert aus HTML5-Data auslesen

  // Wert in Modal-Formuar übernehmen
  var $modal = $(this)
  $modal.find('input[name="text-modal"]').val(value)
})

// Daten abholen
$('form[name="exampleModalForm3"]').on('submit', function (event) {
  event.preventDefault() // Absenden des Formular unterdrücken

  var $modal = $('#modal-init-demo2')
  $modal.modal('hide') // den Modal-Dialog schließen

  var $form = $(this)
  alert($form.serialize()) // Daten aus dem Formular übernehmen
})
```

### Größe

Die Größe des Modal-Dialogs kann mit den CSS-Klassen `.modal-small`
und `.modal-large` beeinflusst werden:

```html
<!-- groß -->
<div class="modal fade" aria-labelledby="exampleModalLabel4"
    aria-hidden="true" role="dialog">
  <div class="modal-dialog modal-large">
    ...
  </div>
</div>

<!-- klein -->
<div class="modal fade" aria-labelledby="exampleModalLabel4"
    aria-hidden="true" role="dialog">
  <div class="modal-dialog modal-small">
    ...
  </div>
</div>
```

## Verwendung

Der Modal-Dialog kann derzeit über zwei Schnittstellen gestartet werden.

### HTML Attribut
```html
<button type="button" data-toggle="modal" data-target="#eg-modal">Modal-Dialog</button>
```

### JavaScript
```js
$('#eg-modal').modal(options)
```

<table class="table table-small">
  <caption>Optionen</caption>
  <thead>
    <tr>
      <th>Name</th>
      <th>Typ</th>
      <th>Standard</th>
      <th>Beschreibung</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>backdrop</td>
      <td>Bool</td>
      <td>true</td>
      <td>
        Gibt an ob der Modal-Dialog durch einen Hintergrund abgesetzt werden soll.
        Der Modal-Dialog wird bei einem Klick auf den Hintergrund geschlossen.
      </td>
    </tr>
    <tr>
      <td>keyboard</td>
      <td>Bool</td>
      <td>true</td>
      <td>Gibt an, ob der Modal-Dialog durch drücken der ESC-Taste geschlossen wird.</td>
    </tr>
    <tr>
      <td>show</td>
      <td>Bool</td>
      <td>true</td>
      <td>Gibt an ob der der Modal-Dialog beim Initialisieren angezeigt werden soll.</td>
    </tr>
  </tbody>
</table>

```js
// Initialisieren des Modal-Dialogs ohne direkte Anzeige
$('#eg-modal').modal({ show: false })
```

<table class="table table-small">
  <caption>Events</caption>
  <thead>
    <tr>
      <th>Typ</th>
      <th>Beschreibung</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>show.tc.modal</td>
      <td>Dieses Event tritt noch vor dem eigentlichen Anzeigen des Modal-Dialogs auf.</td>
    </tr>
    <tr>
      <td>shown.tc.modal</td>
      <td>Dieses Event tritt auf, wenn der Modal-Dialog fertig angezeigt wird.</td>
    </tr>
    <tr>
      <td>hide.tc.modal</td>
      <td>Dieses Event tritt noch vor dem eigentlichen Schließen des Modal-Dialogs auf.</td>
    </tr>
    <tr>
      <td>hidden.tc.modal</td>
      <td>Dieses Event tritt auf, wenn der Modal-Dialog fertig geschlossen wurde.</td>
    </tr>
  </tbody>
</table>

```js
$('#eg-modal').on('hide.tc.modal', function (event) {
  // ...
})
```