## Webfonts
Die Codecomponenten verwenden Webfonts für die Darstellung der Schrift und der Icons.
<div class="tc-note tc-note-info">
  **Hinweis:**
  Auf Telekom Standard-Arbeitsplätzen werden Webfonts im Internet Explorer nur
  dargestellt wenn sie von einer Trustet Domain bereitgestellt werden.
  (z.B. Telekom.de oder design.telekom.com)
</div>

## Schriftbasis

Den gesamten Code Components liegt ein Gestaltungsraster zugrunde, dass
auf einer Schriftgröße von 18px und einer Zeilenhöhe von 120% basiert.

Die dabei verwendete Schriftart ist die Telegrotesk im Schnitt `regular`.

Um diese Grundsätze in allen Komponenten sicherzustellen wurden sie direkt
auf den `<body>` angewendet und werden somit auf fast alle Elemente
wie beispielsweise `<h1>` oder `<p>` automatisch übertragen:

<div class="tc-example">
  <h1>Lorem ipsum dolor</h1>
  <p>
    Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
    sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
    aliquyam erat, sed diam voluptua. At vero eos et accusam et justo
    duo dolores et ea rebum.
  </p>
</div>

```html
<h1>...</h1>
<p>...</p>
```

Es stehen außerdem die Schriftschnitte `halbfett` und `fett` zur Verfügung:

<div class="tc-example">
  <p class="text-semibold">
    Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
    sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
    aliquyam erat, sed diam voluptua.
  </p>
  <p class="text-bold">
    Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
    sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
    aliquyam erat, sed diam voluptua.
  </p>
</div>

```html
<p class="text-semibold">...</p>
<p class="text-bold">...</p>
```

## Lizenzinformation für Telegrotesk Schriftart

Die Schriftart "Telegrotesk" darf nur von Mitarbeitern der Deutschen Telekom
AG kostenfrei geladen und verwendet werden. Sie darf nicht an Dritte
weitergegeben werden. Bitte kontaktieren sie zum Thema Schrift den Brand
Design Support [support(at)branddesign.telekom.com](mailto:support@branddesign.telekom.com).

Alle Agenturen, Auftragnehmer, Leistungserbringer oder sonstige
Geschäftspartner sind verpflichtet, die Schriftart von URW++ zu
erwerben.

<br>
<address itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
  <p class="address-header">
    <span itemprop="name">URW++ Design & Development</span>
  </p>
  <p class="address-body">
    <span itemprop="streetAddress">Poppenbütteler Bogen 36</span><br>
    <span itemprop="postalCode">22399</span>
    <span itemprop="addressLocality">Hamburg</span><br>
    <span itemprop="addressCountry">Germany</span>
  </p>
  <p class="address-footer">
    <label>Tel.:</label><a href="tel:+4940606050" itemprop="telephone">+49 40 60605 0</a><br>
    <label>E-Mail:</label><a href="mailto:info@urwpp.de" itemprop="email">info@urwpp.de</a><br>
    <a href="http://www.urwpp.de" itemprop="email">www.urwpp.de</a> (IdentiType)
  </p>
</address>
