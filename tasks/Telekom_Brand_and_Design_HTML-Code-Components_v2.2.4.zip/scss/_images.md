<!--
//
//
// Bilder
-->

Bilder werden in der Regel mit dem `<img>`-Tag ausgezeichnet.
Sie kommen ausschließlich mit Rahmen vor. Die CSS-Klasse
`.img-vignette-square` sorgt für die Umrandung:

<div class="tc-example">
  <div class="img-vignette-square">
    <img src="assets/play.jpg" width="252" height="168" alt="Beispielbild">
  </div>
</div>

```html
<div class="img-vignette-square">
  <img src="{url}" width="252" height="168" alt="Beispielbild">
</div>
```