<h2 class="underline">Release Notes</h2>

### 2.2.4 <small>[19.04.2018]</small>
  - Farb-Anpassungen für Accessibility

### 2.2.2 <small>[21.02.2017]</small>
  - Collapse-Plugin CSS-Klassen hinzugefügt

### 2.2.2 <small>[21.02.2017]</small>
  - Collapse-Plugin aktualisiert

### 2.2.1 <small>[23.01.2017]</small>
  - Bugfix in Selectbox-Plugin

### 2.2.0 <small>[26.10.2016]</small>
  - New Release

### 2.2.0-rc.1 <small>[26.10.2016]</small>
  - Brand Header
  - Brand Footer

### 2.1.0 <small>[04.08.2016]</small>
  - New Release

### 2.1.0-rc.1 <small>[02.08.2016]</small>
  - Feinheiten bzgl. neues UI-Kit

### 2.1.0-alpha.2 <small>[26.07.2016]</small>
  - Responsive Tabelle CSS-Klasse
  - Radio und Checkbox Visiablisierung verbessert
  - Vereinfachung im Grid-Nesting
  - Vereinfachung der Visibility- und Hidden-Klassen

### 2.1.0-alpha <small>[21.07.2016]</small>
  - Umstrukturierung im Projekt
  - Anpassungen neues UI-Kit
  - Neuer Screen-Font
  - Neue BU Berechnungen
  - Font Probleme behoben
  - Neue Hilfsklassen

### 2.0.1 <small>[26.06.2015]</small>
  - Verbesserungen bei der Verwendung der Selectbox auf mobilen Geräten
  - Diverse Änderungen in der Dokumentation
  - Verbesserungen des Focus-Effekts auf Einabgefeldern
  - Anpassungen des Layouts im Modal-Dialog

### 2.0.0 <small>[08.06.2015]</small>
  - 2.0.0 Release

### 2.0.0-beta.10 <small>[01.06.2015]</small>
  - Verbesserungen hinsichtlich Benutzbarkeit durch Dependency Manager
  - Diverse Accessibility Verbesserungen
  - Diverse Verbesserungen der Dokumentation (Anmerkungen etc.)

### 2.0.0-beta.9 <small>[19.02.2015]</small>
  - Tooltip hinzugefügt
  - Tooltip Dokumentation hinzugefügt
  - Icon-Font aktualisiert
  - Einbindung des neuen Screen-Fonts
  - Diverse Accessibility Verbesserungen
  - keyboard.js entfernt um JavaScript zu minimieren

### 2.0.0-beta.8 <small>[20.01.2015]</small>
  - JavaScript Button hinzugefügt
  - JavaScript Toggle Button hinzugefügt
  - JavaScript Button Group Radio hinzugefügt
  - JavaScript Button Group Checkbox hinzugefügt
  - JavaScript Expandabe hinzugefügt
  - JavaScript Expandabe Group hinzugefügt
  - JavaScript Modal hinzugefügt
  - JavaScript To Top hinzugefügt
  - IconFont Outline hinzugefügt
  - IconFont Solid hinzugefügt
  - Dark-Theme hinzugefügt
  - Diverse CSS Verbesserungen
  - Diverse Accessibility Verbesserungen

### 2.0.0-beta.7 <small>[05.01.2015]</small>
  - Responsive-Helfer "Visible-Hidden" hinzugefügt
  - Responsive Ausrichtung für Text hinzugefügt
  - Heroheadline hinzugefügt
  - ThinHeadline hinzugefügt
  - Thin als Textdecoration hinzugefügt
  - Einfache unsortierte Liste hinzugefügt

### 2.0.0-beta.6 <small>[18.12.2014]</small>
  - Neues Modul Badges hinzugefügt
  - Neues Modul Benachrichtigungen hinzugefügt
  - Accessibility Verbesserungen in Checkbox, Radiobutton, Dropdown, Streichpreis
  - Accessibility Anmerkunden in Dokumentation
  - Content-Listen erweitert und hinsichtlich Accessibility verbessert
  - Fehlerhafte Tabellen-Footer-Auszeichnungen korrigiert
  - Pagination hinsichtlich High-Contract-Mode verbessert
  - Clean-Button hinsichtlich High-Contract-Mode verbessert

### 2.0.0-beta.5 <small>[17.09.2014]</small>
  - Helfer für horizontales und vertikales Zentrieren hinzugefügt
  - Background-Colors hinzugefügt
  - Responsives Verhalten der Description List verbessert
  - Abstände des Thread Views und des Zitats verbessert

### 2.0.0-beta.4 <small>[05.09.2014]</small>
  - Breadcrumb hinzugefügt
  - Pagination hinzugefügt
  - Content-Liste Select- und Hover-Zustand hinzugefügt
  - Responsive Element Offset Helper hinzugefügt
  - XL-Grid-Size hinzugefügt
  - Accessibility Verbesserungen der Selectbox
  - Accessibility Verbesserungen der Radio-Buttons innerhalb von Button-Gruppen
  - Pointer-Verhalten bei Radio-Buttons uns Checkboxen hinzugefügt
  - Breadcrumb Dokumentation hinzugefügt
  - Pagination Dokumentation hinzugefügt
  - Content List, Selectstate and Hover Beispiele in Dokumentation
  - Responsive Element Offset Dokumentation hinzugefügt

### 2.0.0-beta.3 <small>[29.08.2014]</small>
  - Responsive Grid System hinzugefügt
  - Responsive Grid Dokumentation hinzugefügt
  - Content List-Modul hinzugefügt
  - Icon-Verwendung Dokumentation verbessert
  - Responsive Debug Tool hinzugefügt
  - CSS Debug Theme hinzugefügt

### 2.0.0-beta.2 <small>[14.08.2014]</small>
  - Aktualisierung Dokumentation - Installationsanweisungen
  - Accessibility Anpassungen
  - Grid Bugfixes

### 2.0.0-beta.1 <small>[15.07.2014]</small>
  - Accessibility Verbesserungen
  - Bilder ohne Outline
  - Refactoring marked-text and ellipsed

### 2.0.0-beta <small>[30.06.2014]</small>
  - Abstände von Elementen verbesser
  - Hover-Animationen eingeführt

### 2.0.0-alpha <small>[12.06.2014]</small>
  - Erste Prereleaseversion nach Entwicklung
  - CSS-Reset, Typografie, Input, Buttons, Images, Table, Icons, Basic-Grid
