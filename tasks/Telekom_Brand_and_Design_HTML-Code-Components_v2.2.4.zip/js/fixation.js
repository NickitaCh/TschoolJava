+function ($) {
  'use strict';

  var Fixation = function (element, options) {
    this.options = $.extend({}, Fixation.DEFAULTS, options)

    this.$target = $(this.options.target)
      .on('scroll.tc.fixation.data-api', $.proxy(this.checkPosition, this))

    this.$element = $(element)

    this.checkPosition()
  }

  Fixation.DEFAULTS = {
    offsetTop: 0,
    target: window
  }

  Fixation.prototype.checkPosition = function () {
    var scrollTop = this.$target.scrollTop()
    var position = this.$element.offset()
    var offsetTop = this.options.offsetTop

    if (typeof offsetTop == 'function') offsetTop = offsetTop(this.$element)

    this.$element.toggleClass('fixed', (scrollTop > (position.top - offsetTop)));
  }

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.fixation')
      var options = typeof option == 'object' && option

      if (!data) $this.data('tc.fixation', (data = new Fixation(this, options)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.fixation

  $.fn.fixation = Plugin
  $.fn.fixation.Constructor = Fixation


  // FIXATION NO CONFLICT
  // =================

  $.fn.fixation.noConflict = function () {
    $.fn.fixation = old
    return this
  }

  $(window).on('load', function () {
    $('[data-spy="fixation"]').each(function () {
      var $spy = $(this)
      var data = $spy.data()

      Plugin.call($spy, data)
    })
  })

}(window.jQuery);

