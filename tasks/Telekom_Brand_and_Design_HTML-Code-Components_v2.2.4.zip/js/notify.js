+function ($) {
  'use strict';

  var anchors = {};

  var Notify = function (element, options) {
    this.$element = $(element)
    this.options  = this.getOptions(options)

    this.$viewport = this.options.viewport && $(this.options.viewport.selector || this.options.viewport)
  }

  Notify.DEFAULTS = {
    template: '<div class="notification">' +
            '</div>',
    anchor: '<div></div>',
    placement: 'top-right',
    viewport: 'body'
  }

  Notify.prototype.run = function (message) {
//    var $notification = new Notification(message);
//    $notification.show
//    var $notification = this.notification();
//    $notification.html(message);
//
//    this.show();
//
//    var thiz = this;
//    setTimeout(function () {
//      thiz.hide();
//    }, 10000)
  }

  Notify.prototype.show = function () {
    var $anchor = this.getAnchor();
    var $notification = this.notification();
    $anchor.prepend($notification);
  }

  Notify.prototype.getAnchor = function () {
    var anchor = anchors['top-right'];
    if (!anchor) {
      anchor = anchors['top-right'] = $(this.options.anchor);
      anchor.css({
        top: 0,
        right: 0
      }).addClass('notification-anchor');
      this.$viewport.append(anchor);
    }
    return anchor;
  }

  Notify.prototype.getElementPosition = function () {
    if (this.options.viewport != 'body')
      return
  }

  Notify.prototype.hide = function () {
    return this.notification().detach();
  }

  Notify.prototype.getDefaults = function () {
    return Notify.DEFAULTS
  }

  Notify.prototype.getOptions = function (options) {
    options = $.extend({}, this.getDefaults(), this.$element.data(), options)
    return options
  }

  Notify.prototype.notification = function () {
    return this.$notification = this.$notification || $(this.options.template)
  }

  // NOTIFY PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.notify')
      var options = typeof option == 'object' && option

      if (!data)
        $this.data('tc.notify', (data = new Notify(this, options)))
      if (typeof option == 'string')
        data.run(option)
//      if (typeof option == 'string') data[option].call($this)
    })
  }

  var old = $.fn.notify

//  $.notify                = function (message) {
//    new Notify(message);
//  }

  $.fn.notify = Plugin
  $.fn.notify.Constructor = Notify


  // NOTIFY NO CONFLICT
  // ====================

  $.fn.notify.noConflict = function () {
    $.fn.notify = old
    return this
  }

}(window.jQuery);
