+function ($) {
  'use strict';


  var BrandNavHead = function (element, options) {
    this.options = $.extend({}, BrandNavHead.DEFAULTS, options)

    this.$target = $(this.options.target)
      .on('show.tc.brandnav', $.proxy(this.update, this))
      .on('hide.tc.brandnav', $.proxy(this.update, this))

    this.$element = $(element)

    this.$label = this.$element.find('.brandnav-label')
    this.$controlUp = this.$element.find('.brandnav-control-up')

    this.storeLabel()
  }

  BrandNavHead.VERSION = '1.0.0'

  BrandNavHead.TRANSITION_DURATION = 300

  BrandNavHead.DEFAULTS = {
    target: window
  }

  BrandNavHead.prototype.storeLabel = function (e) {
    this.$label.data('root-label', this.$label.text())
  }

  BrandNavHead.prototype.update = function (e) {
    this.updateLabel(e)
    this.updateControls(e)
  }

  BrandNavHead.prototype.updateLabel = function (e) {
    var text = e.target.siblings('[data-open="brandnav"]').text()
    this.$label.text(text || this.$label.data('root-label'))
  }

  BrandNavHead.prototype.updateControls = function (e) {
    this.$controlUp.toggleClass('in', !!e.target.parents('.brandnav').length)
  }

  // MENU PLUGIN DEFINITION
  // =======================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.brandnavhead')

      if (!data) $this.data('tc.brandnavhead', (data = new BrandNavHead(this)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.brandnavhead

  $.fn.brandnavhead = Plugin
  $.fn.brandnavhead.Constructor = BrandNavHead


  // BRANDNAVHEAD NO CONFLICT
  // =================

  $.fn.brandnavhead.noConflict = function () {
    $.fn.brandnavhead = old
    return this
  }

  // BRANDNAVHEAD DATA-API
  // ==============

  $(document).on('click.tc.brandnavhead.data-api', '[data-spy="brandnav"]', function (e) {
    e.preventDefault() // only accept click events on button inside
  })

  $(window).on('load.tc.brandnavhead.data-api', function () {
    $('[data-spy="brandnav"]').each(function () {
      var $spy = $(this)
      Plugin.call($spy, $spy.data())
    })
  })

}(window.jQuery);
