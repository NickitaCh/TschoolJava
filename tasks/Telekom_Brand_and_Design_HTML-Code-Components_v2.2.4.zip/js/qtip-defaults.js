+function ($) {
  'use strict';

  if ($.fn.qtip) { // if qtip enabled... set tc-design defaults
    $.fn.qtip.defaults.position.my = 'bottom center';
    $.fn.qtip.defaults.position.at = 'top center';
  }

}(window.jQuery);
