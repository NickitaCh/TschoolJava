+function ($) {
  'use strict';

  var Button = function (element, options) {
    this.options =
    this.$element = null
    this.buttonGroup = false
    this.init(element, options)
  }

  Button.DEFAULTS = {}

  Button.prototype.init = function (element, options) {
    var $e = this.$element = $(element)
    if ($e.hasClass('active') === true) this.$element.attr('aria-pressed', true)
  }

  Button.prototype.setActiveStateGroup = function () {
    this.buttonGroup = true
    this.setActiveState()
  }

  Button.prototype.setActiveStateRadioGroup = function (state) {
    this.buttonGroup = true
    var $e = this.$element
    var $parrent = $e.parent()
    var eIndex = $($e).index()
    var pointer = this
    $parrent.children('button').each(function (index) {
      var $ce = $(this);
      if (index != eIndex) if (!$ce.prop('disabled') && $ce.hasClass('active')) pointer.setActiveState($ce, true)
    })
    if (!$e.hasClass('active')) this.setActiveState($e, false)
  }


  Button.prototype.setNewState = function (state) {
    var $e = this.$element
    switch (state) {
      case 'default':
        this.setActiveState($e, true)
        this.setDisableState($e, true)
        break
      case 'active':
        this.setActiveState($e, false)
        break
      case 'enable':
        this.setDisableState($e, true)
        break
      case 'disable':
        this.setDisableState($e, false)
        break
      case 'toggledisable':
        this.setDisableState()
        break
      case 'toggleactive':
        this.setActiveState()
        break
    }
  }



  Button.prototype.setDisableState = function ($e, state) {
    if ($e === undefined) $e = this.$element
    if (state === undefined) state = $e.prop('disabled')
    if (state === false) {
      $e.prop('disabled', true)
      this.setActiveState($e, true)
      this.callFunction($e, 'd')
    } else if (state === true) {
      $e.prop('disabled', false)
      this.callFunction($e, 'e')
    }
  }



  Button.prototype.setActiveState = function ($e, state) {
    if ($e === undefined) $e = this.$element
    if (state === undefined) state = $e.hasClass('active')
    this.$element.attr('aria-pressed', state ? false : true)
    if (state === false) {
      $e.addClass('active')
      this.callFunction($e, 'active')
    } else if (state === true) {
      $e.removeClass('active')
      $e.blur();
      this.callFunction($e, 'inactive')
    }
  }


  Button.prototype.callFunction = function ($e, type) {
    var callbackFilter = ''
    var callback = 'data-callback'
    var filter = 'data-callback-states'
    if ($e === undefined) $e = this.$element
    var callbackFunction = $e.attr(callback)
    if (this.buttonGroup === true) callbackFilter = $e.parent().attr(filter)
    else callbackFilter = $e.attr(filter)
    if (callbackFunction !== undefined) {
      if (type === 'press') window[callbackFunction]($e, type) // window[callbackFunction].call($e, type)
      else if (callbackFilter === 'all') window[callbackFunction]($e, type) // window[callbackFunction].call($e, type)
    }
  }


  // Button PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.button')
      var options = typeof option == 'object' && option
      if (!data) $this.data('tc.button', (data = new Button(this, options)))
      if (option == 'toggleActiveState') data.setActiveState()
      if (option == 'toggleActiveStateRadioGroup') data.setActiveStateRadioGroup(false)
      if (option == 'toggleActiveStateGroup') data.setActiveStateGroup()
      if (option == 'forwardPressState') data.callFunction (undefined, 'press')
      else if (option) data.setNewState(option)
      /*if (typeof option == 'string') data[option].call($this)*/
    })
  }

  var old = $.fn.button

  $.fn.button = Plugin
  $.fn.button.Constructor = Button

  // Button API
  // ====================

  $(document).on('click.tc.button.data-api', '[data-toggle="button"]', function (e) {
    var $e = $(e.target)
    Plugin.call($e, 'toggleActiveState')
    Plugin.call($e, 'forwardPressState')
  })

  $(document).on('click.tc.button.data-api', '[data-toggle="buttongroup-radio"]', function (e) {
    var $e = $(e.target)
    Plugin.call($e, 'toggleActiveStateRadioGroup')
    Plugin.call($e, 'forwardPressState')
  })

  $(document).on('click.tc.button.data-api', '[data-toggle="buttongroup"]', function (e) {
    var $e = $(e.target)
    Plugin.call($e, 'toggleActiveStateGroup')
    Plugin.call($e, 'forwardPressState')
  })

  // Button NO CONFLICT
  // ====================

  $.fn.button.noConflict = function () {
    $.fn.button = old
    return this
  }

}(window.jQuery);
