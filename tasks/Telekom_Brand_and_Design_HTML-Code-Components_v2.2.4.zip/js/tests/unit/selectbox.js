$(function () {

  module('selectbox plugin')

  test('should be defined on jquery object', function () {
    var div = $('<div></div>');
    ok(div.selectbox, 'select method is defined')
  })

  module('selectbox', {
    setup: function () {
      $.fn.componentsSelectBox = $.fn.selectbox.noConflict()
    },
    teardown: function () {
      $.fn.selectbox = $.fn.componentsSelectBox
      delete $.fn.componentsSelect
    }
  })

  test('should provide no conflict', function () {
    ok(!$.fn.selectbox, 'select was set back to undefined (org value)')
  })

  test('should return element', function () {
    var el = $('<div></div>')
    ok(el.componentsSelectBox()[0] === el[0], 'same element returned')
  })

  test('should expose default settings', function () {
    ok(!!$.fn.componentsSelectBox.Constructor.DEFAULTS, 'defaults is defined')
  })

  test('should hide the default ui element', function () {
    var select = $('<select name="select"><option>1</option></select>').componentsSelectBox()
    ok(select.hasClass('hidden'), 'hide class is added');
  })

  test('should prepend the new ui element', function () {
    var select = $('<select name="select"><option>1</option></select>').componentsSelectBox()
    var jsselect = select.prev()

    ok(jsselect.hasClass('form-select-js'), 'form-select-js class is added');
  })

  test('should not open if select is disabled', function () {
    var select = $('<select name="select" disabled><option>1</option></select>').componentsSelectBox()
    var jsselect = select.prev()

    jsselect.find('.form-select-js-choice').click()

    ok(!jsselect.hasClass('in'), 'in class added on click');
  })

  test('should not execute if its not a select', function () {
    var select = $('<div></div>').componentsSelectBox()
    var jsselect = select.prev()

    ok(!jsselect.hasClass('.form-select-js'), 'form-select-js class found');
  })

  test('should remove in class if body clicked', function () {
    var select = $('<select name="select"><option>1</option></select>')
            .appendTo('#qunit-fixture')
            .componentsSelectBox()

    var jsselect = select.prev()

    jsselect.find('.form-select-js-choice').click()

    ok(jsselect.hasClass('in'), 'in class added on click');
    $('body').click();
    ok(!jsselect.hasClass('in'), 'in class removed');
    select.remove();
    jsselect.remove();
  })

  test('should remove in class of multiple if body clicked', function () {
    var selectboxesHtml = '<select name="select"><option>1</option></select>' +
            '<select name="select2"><option>1</option></select>'

    var select = $(selectboxesHtml)
            .appendTo('#qunit-fixture')
            .componentsSelectBox()

    var jsselectFirst = select.first().prev()
    var jsselectLast = select.last().prev()

    ok(select.length === 2, 'Should be two selects')

    jsselectFirst.find('.form-select-js-choice').click()
    ok(jsselectFirst.hasClass('in'), 'in class added on click');
    ok($('#qunit-fixture .in').length === 1, 'only one object is in')
    $('body').click();
    ok($('#qunit-fixture .in').length === 0, 'in class removed')

    jsselectLast.find('.form-select-js-choice').click()
    ok(jsselectLast.hasClass('in'), 'in class added on click');
    ok($('#qunit-fixture .in').length === 1, 'only one object is in')
    $('body').click();
    ok($('#qunit-fixture .in').length === 0, 'in class removed')

    $('#qunit-fixture').html('')
  })

})
