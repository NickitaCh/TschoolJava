$(function () {

  module('modal plugin')

  test('should be defined on jquery object', function () {
    ok($(document.body).modal, 'modal method is defined')
  })

  module('modal', {
    setup: function () {
      $.fn.componentsModal = $.fn.modal.noConflict()
    },
    teardown: function () {
      $.fn.modal = $.fn.componentsModal
      delete $.fn.componentsModal
    }
  })

  test('should provide no conflict', function () {
    ok(!$.fn.modal, 'modal was set back to undefined (org value)')
  })

  test('should return jquery collection containing the element', function () {
    var $el = $('<div id="modal-test"></div>')
    var $modal = $el.componentsModal()
    ok($modal instanceof $, 'returns jquery collection')
    strictEqual($modal[0], $el[0], 'collection contains element')
  })

  test('should expose default settings', function () {
    ok(!!$.fn.componentsModal.Constructor.DEFAULTS, 'defaults is defined')
  })

})
