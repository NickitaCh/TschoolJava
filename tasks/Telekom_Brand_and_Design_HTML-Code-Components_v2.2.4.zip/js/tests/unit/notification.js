$(function () {

  module('notification plugin')

  test('should be defined on jquery object', function () {
    ok($(document.body).notification, 'notification method is defined')
  })

  module('notification', {
    setup: function () {
      $.fn.componentsNotification = $.fn.notification.noConflict()
    },
    teardown: function () {
      $.fn.notification = $.fn.componentsNotification
      delete $.fn.componentsNotification
    }
  })

  test('should provide no conflict', function () {
    ok(!$.fn.notification, 'notification was set back to undefined (org value)')
  })

  test('should return jquery collection containing the element', function () {
    var $el = $('<div id="notification-test"></div>')
    var $notification = $el.componentsNotification()
    ok($notification instanceof $, 'returns jquery collection')
    strictEqual($notification[0], $el[0], 'collection contains element')
  })

  test('should be removed on clicking .close', function () {
    var notificationHtml = '<div class="notification notification-dismissible">'
            + '<button type="button" class="close" data-dismiss="notification">x</button>'
            + 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed dia.'
            + '</div>';

    var $notification = $(notificationHtml).appendTo('#qunit-fixture').componentsNotification()

    notEqual($('#qunit-fixture').find('.notification').length, 0, 'element added to dom')

    $notification.find('.close').click()

    equal($('#qunit-fixture').find('.notification').length, 0, 'element removed from dom')
  })

})
