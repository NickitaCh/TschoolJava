$(function () {

  module('radio plugin')

  test('should be defined on jquery object', function () {
    var div = $('<div></div>');
    ok(div.radio, 'radio method is defined')
  })

  module('radio', {
    setup: function () {
      $.fn.componentsRadio = $.fn.radio.noConflict()
    },
    teardown: function () {
      $.fn.radio = $.fn.componentsRadio
      delete $.fn.componentsRadio
    }
  })

  test('should provide no conflict', function () {
    ok(!$.fn.radio, 'radio was set back to undefined (org value)')
  })

  test('should return element', function () {
    var $el = $('<div></div>')
    ok($el.componentsRadio() == $el, 'same element returned')
  })

  test('should expose default settings', function () {
    ok(!!$.fn.componentsRadio.Constructor.DEFAULTS, 'defaults is defined')
  })

  test('should hide the default ui element', function () {
    var $radio = $('<input type="radio" name="radio"/>').componentsRadio()
    ok($radio.hasClass('hidden'), 'hide class is added');
  })

  test('should prepend the new ui element', function () {
    var $radio = $('<input type="radio" name="radio"/>').componentsRadio()
    var $jsradio = $radio.prev()
    ok($jsradio.hasClass('form-radio-js'), 'form-radio-js is added');
  })

  test('should copy disabled property as class to the new ui element', function () {
    var $radio = $('<input type="radio" name="radio" disabled/>').componentsRadio()
    var $jsradio = $radio.prev()
    ok($jsradio.hasClass('disabled'), 'form-radio-js is disabled');
  })

})
