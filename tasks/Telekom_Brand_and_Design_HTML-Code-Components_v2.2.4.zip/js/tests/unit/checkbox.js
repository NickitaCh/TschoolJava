$(function () {

  module('checkbox plugin')

  test('should be defined on jquery object', function () {
    var div = $('<div></div>');
    ok(div.checkbox, 'checkbox method is defined')
  })

  module('checkbox', {
    setup: function () {
      $.fn.componentsCheckbox = $.fn.checkbox.noConflict()
    },
    teardown: function () {
      $.fn.checkbox = $.fn.componentsCheckbox
      delete $.fn.componentsCheckbox
    }
  })

  test('should provide no conflict', function () {
    ok(!$.fn.checkbox, 'checkbox was set back to undefined (org value)')
  })

  test('should return element', function () {
    var $el = $('<div></div>')
    ok($el.componentsCheckbox()[0] == $el[0], 'same element returned')
  })

  test('should expose default settings', function () {
    ok(!!$.fn.componentsCheckbox.Constructor.DEFAULTS, 'defaults is defined')
  })

  test('should hide the default ui element', function () {
    var $checkbox = $('<input type="checkbox" name="checkbox"/>').componentsCheckbox()
    ok($checkbox.hasClass('hidden'), 'hide class is added');
  })

  test('should prepend the new ui element', function () {
    var $checkbox = $('<input type="checkbox" name="checkbox"/>').componentsCheckbox()
    var $jscheckbox = $checkbox.prev()
    ok($jscheckbox.hasClass('form-checkbox-js'), 'form-checkbox-js class is added');
  })

  test('should copy disabled property as class to the new ui element', function () {
    var $checkbox = $('<input type="checkbox" name="checkbox" disabled/>').componentsCheckbox()
    var $jscheckbox = $checkbox.prev()
    ok($jscheckbox.hasClass('disabled'), 'form-checkbox-js is disabled');
  })

  test('should apply tabindex property as attribute to the new ui element', function () {
    var $checkbox = $('<input type="checkbox" name="checkbox" tabindex="99"/>').componentsCheckbox()
    var $jscheckbox = $checkbox.prev()
    equal($jscheckbox.attr('tabindex'), '99', 'form-checkbox-js tabindex has been applied');
  })

  test('should have correct aria-checked and checked class on change', function () {
    var $checkbox = $('<input type="checkbox" name="checkbox"/>').componentsCheckbox()
    var $jscheckbox = $checkbox.prev()

    // unchecked case
    $checkbox.trigger('change')
    equal($jscheckbox.attr('aria-checked'), 'false', 'aria-checked is false')
    ok(!$jscheckbox.hasClass('checked'), 'checked class is removed')

    // checked case
    $checkbox.prop('checked', true).trigger('change')
    equal($jscheckbox.attr('aria-checked'), 'true', 'aria-checked is true')
    ok($jscheckbox.hasClass('checked'), 'checked class is added')
  })

})
