$(function () {

  module('modal plugin')

  test('should be defined on jquery object', function () {
    ok($(document.body).totop, 'totop method is defined')
  })

  test('should provide no conflict', function () {
    ok(!$.fn.totop, 'totop was set back to undefined (org value)')
  })

})
