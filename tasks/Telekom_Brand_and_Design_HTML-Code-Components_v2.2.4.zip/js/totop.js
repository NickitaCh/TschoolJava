+function ($) {
  'use strict';
  var show = false;
  var mobileSupport = false
  var timeout

  var ToTop = function (element, options) {
    this.options  =
    this.$element = null

    this.init(element, options)
  }

  ToTop.DEFAULTS = {
    buttonText: { de:'Nach Oben', en:'To Top' },
    language: 'auto',
    smallButton: false,
    buttonOpacity: 0.92,
    scrollOffset: 50,
    scrollTimeMax: 800,
    scrollTimeMin: 250,
    pixelPerSecond: 4000,
    mobileBreakpoint: 639,
    dynamicVisibility: true,
    dynamicVisibilityTime: 2000,
    theme: '',
    containerType: 'container-fixed'
  }

  ToTop.prototype.init = function (element, options) {
    var $e = this.$element = $(element)
    this.options = this.mergeOptions(options)
    if (!this.options.language || this.options.language === 'auto') {
      this.options.language = this.getDocumentLanguage()
    }

    var object = this

    if ($.support.mobile === true) {
      mobileSupport = true;
      this.options.dynamicVisibility = false
    }

    if (mobileSupport === true || this.options.smallButton === true || $(window).width() < this.options.mobileBreakpoint) {
      this.generateButton(true, false)
    } else {
      this.generateButton(false, false)
    }

    this.showHideButton()

    $(window).scroll(function () {
      object.showHideButton()
    })

    $(window).resize(function () {
      var width = $(window).width()
      if (width < 639) {
        object.generateButton(true, true)
      } else if (width > 640){
        object.generateButton(false, true)
      }
    })

    $('body').mousemove(function () {
      if (show === false) {
        object.toggleButtonVisibility(true)
        object.dynamicVisibility()
      }
    })
  }

  ToTop.prototype.mergeOptions = function (options) {
    options = options.option;
    var returnObj = {}
    var settingName
    var defaults = this.getDefaults();
    for (settingName in defaults) { returnObj[settingName] = defaults[settingName] }
    for (settingName in options) { returnObj[settingName] = options[settingName] }
    return returnObj;
  }

  ToTop.prototype.showHideButton = function () {
    if ($(window).scrollTop() > this.options.scrollOffset && show === false) {
      show = true
      $('.totop').css({
        bottom: '0px',
        opacity: this.options.buttonOpacity
      })
      this.dynamicVisibility()
    } else if ($(window).scrollTop() < this.options.scrollOffset && show === true) {
      show = false
      $('.totop').css({
        bottom: '-70px',
        opacity: 0
      })
    }
  }

  ToTop.prototype.toggleButtonVisibility = function (visible) {
    if (visible === true) {
      show = true
      $('.totop').css({ opacity: this.options.buttonOpacity })
    } else if (visible === false) {
      show = false
      $('.totop').css({ opacity: 0 })
    }
  }

  ToTop.prototype.generateButton = function (type, replace) {
    var object = this
    var options = this.options
    var finalButton = ''
    var buttontext = this.options.buttonText[this.options.language];


    var button = '<button type="button" id="totopButton" class="btn btn-default btn-minimal">' +
                 '<i class="icon icon-export" aria-hidden="true">' +
                 '</i>' + buttontext + '</button>'

    if (type === true) {
      button = '<button type="button" id="totopButton" class="btn btn-default btn-icon mobile" title="' + buttontext + '">' +
               '<i class="icon icon-export" aria-hidden="true"></i>' +
               '</button>'
    }

    if (replace === true) {
      finalButton = button
      $('#totopButton').detach()
      $('#button-wrap').append(finalButton)


    } else if (replace === false) {

      finalButton = '<div class="totop">' +
                    '<div class="' + options.containerType + '">' +
                    '<div class="row">' +
                    '<div id="button-wrap">' + button +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>'

      $('body').append(finalButton)
    }

    if (options.theme) {
      $('#totopButton').addClass(options.theme)
    }

    $('#totopButton').click(function (e) {
      e.preventDefault();

      var position = $(window).scrollTop();
      var scrollspeed = Math.round(1000 * (position / options.pixelPerSecond));
      scrollspeed = Math.min(scrollspeed, options.scrollTimeMax)
      scrollspeed = Math.max(scrollspeed, options.scrollTimeMin)

      $('html, body').stop(true,true).animate({ scrollTop: 0 }, scrollspeed)
      clearTimeout(timeout);
    })

    $('#totopButton').mouseenter(function (e) {
      clearTimeout(timeout);
    })

    $('#totopButton').mouseleave(function (e) {
      object.dynamicVisibility()
    })
  }

  ToTop.prototype.dynamicVisibility = function () {
    var object = this

    if (this.options.dynamicVisibility === true) {
      clearTimeout(timeout);
      timeout = setTimeout(function () {
        object.toggleButtonVisibility(false)
        clearTimeout(timeout);
      }, object.options.dynamicVisibilityTime);
    }
  }

  ToTop.prototype.getDocumentLanguage = function () {
    return $('html').attr('lang')
  }

  ToTop.prototype.getDefaults = function () {
    return ToTop.DEFAULTS
  }

  // ToTop PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
   // return this.each(function () {
    var $this = $(this)
    var data = $this.data('tc.totop')
    var options = typeof option == 'object' && option
    if (!data) $this.data('tc.totop', (data = new ToTop(this, options)))
    if (typeof option == 'string') data[option].call($this)
   // })
  }

  var old = $.fn.totop

  $.fn.totop = Plugin
  $.fn.totop.Constructor = ToTop


  // ToTop NO CONFLICT
  // ====================

  $.fn.totop.noConflict = function () {
    $.fn.totop = old
    return this
  }

}(window.jQuery);
