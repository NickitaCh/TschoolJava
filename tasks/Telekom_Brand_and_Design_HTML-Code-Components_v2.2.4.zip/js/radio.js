+function ($) {
  'use strict';

  var formset = '.form-radio-set'
  var Radio = function (element, options) {
    this.options  =
    this.$element = null

    this.init(element, options)
  }

  Radio.DEFAULTS = {
    template: '<div tabindex="-1" class="form-radio-js" role="radio" autocomplete="off" hidefocus="true">' +
            '&nbsp;' + // &nbsp; important für Screenreader
            '<span class="border"></span>' +
            '<span class="check"></span>' +
            '</div>'
  }

  Radio.prototype.init = function (element, options) {
    var $e = this.$element = $(element)
    this.options = this.getOptions(options)
    var $radio = this.radio()
    var name = $e.attr('name')

    $e.before($radio)
    $e.addClass('hidden')

    $e.on('change.tc.radio', function (e) {
      if (name) {
        $('input[name="' + name + '"]:radio:enabled')
                .not($e)
                .trigger('deselect.tc.radio')
      }

      $radio.addClass('checked')
              .attr('aria-checked', 'true')
              .attr('tabindex', '0')
    })

    $e.on('deselect.tc.radio', function (e) {
      $radio.removeClass('checked')
              .attr('aria-checked', 'false')
              .attr('tabindex', '-1')
    })

    $radio.parents(formset).on('click.tc.radio', function (e) {
      if ($radio.is('.disabled, :disabled'))
        return;

      if (!$(e.target).hasClass('form-radio hidden'))
        $e.trigger('click');
    })

    $radio.on('keyup.tc.radio', function (e) {
      if ($radio.is(':focus')) $radio.addClass('focus')
    })

    $radio.on('keydown.tc.radio', function (e) {

      if (!name) return true

      if (e.altkey) {
        return true
      }

      var idx = $('input[name="' + name + '"]:radio:enabled').index($e)

      switch (e.keyCode) {
        case 37:
        case 38:
          if (e.shiftKey) {
            return true;
          }

          $('input[name="' + name + '"]:radio:enabled:eq(' + (idx - 1) + ')')
                  .trigger('click')
                  .prev()
                  .focus()

          e.preventDefault();
          e.stopPropagation();
          return false;
        case 39:
        case 40:

          if (e.shiftKey) {
            return true;
          }

          $('input[name="' + name + '"]:radio:enabled:eq(' + (idx + 1) + ')')
                  .trigger('click')
                  .prev()
                  .focus()

          e.preventDefault();
          e.stopPropagation();
          return false;
      }

      return true;
    })

    $radio.on('keypress.tc.radio', function (e) {
      if (e.altkey) {
        return true
      }

      if (e.keyCode === 37 || e.keyCode === 38 // left/up
              || e.keyCode === 39 || e.keyCode === 40) { // right/down
        e.stopPropagation()
        return false;
      }

      return true;
    })

    $radio.on('blur.tc.radio', function (e) {
      $radio.removeClass('focus')
    })

    if ($e.is(':checked')) {
      $radio.addClass('checked')
              .attr('aria-checked', 'true')
              .attr('tabindex', '0')
    }

    if ($e.is(':disabled') || $e.parents('fieldset').is(':disabled')) {
      this.disable()
    }

    // if it's a group, rest focus
    if (name) {
      var $radioGroup = $('input[name="' + name + '"]:radio:enabled')
      var $focusElem = $radioGroup.filter(':checked')

      if ($focusElem.length < 1) {
        $focusElem = $radioGroup.first()
      }

      $radioGroup.each(function (index, elem) {
        var $elem = $(elem)
        var data = $elem.data('tc.radio')
        if (!data) return
        var radio = data.radio()
        radio.attr('tabindex', $focusElem[0] == elem ? '0' : '-1')
      })
    }
  }

  Radio.prototype.disable = function () {
    var $e = this.$element
    var $radio = this.radio()

    $radio.attr('aria-disabled', true)
            .addClass('disabled')

    $e.parents(formset).addClass('disabled')
  }

  Radio.prototype.enable = function () {
    var $e = this.$element
    var $radio = this.radio()

    $radio.attr('aria-disabled', false)
            .removeClass('disabled')

    $e.parents(formset).removeClass('disabled')
  }

  Radio.prototype.getDefaults = function () {
    return Radio.DEFAULTS
  }

  Radio.prototype.getOptions = function (options) {
    options = $.extend({ }, this.getDefaults(), this.$element.data(), options)
    return options
  }

  Radio.prototype.radio = function () {
    return this.$radio = this.$radio || $(this.options.template)
  }

  // RADIO PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.radio')
      var options = typeof option == 'object' && option

      if (!data) $this.data('tc.radio', (data = new Radio(this, options)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.radio

  $.fn.radio = Plugin
  $.fn.radio.Constructor = Radio


  // RADIO NO CONFLICT
  // ====================

  $.fn.radio.noConflict = function () {
    $.fn.radio = old
    return this
  }

}(window.jQuery);
