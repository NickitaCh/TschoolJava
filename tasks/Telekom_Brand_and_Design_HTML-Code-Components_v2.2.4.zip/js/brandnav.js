+function ($) {
  'use strict';

  var navOpen = '[data-open="brandnav"]'
  var navClose = '[data-close="brandnav"]'
  var navCancel = '[data-cancel="brandnav"]'
  var BrandNav = function (element) {
    this.$element = $(element)
    this.$parent = this.$element.parent()
    this.$parentnav = this.$element.parents('.brandnav').first()

    this.$main = getMain(this.$element)
    this.$body = $('body')
  }

  BrandNav.VERSION = '1.0.0'

  BrandNav.TRANSITION_DURATION = 300

  BrandNav.prototype.show = function () {

    var that = this

    var showEvent = $.Event('show.tc.brandnav', {
      target: this.$element,
      relatedTarget: this.$parentnav
    })

    this.$main.trigger(showEvent)
    if (showEvent.isDefaultPrevented()) return

    this.$body.css('overflow-x', 'hidden')
    this.$parent.siblings().removeClass('active')

    this.$parent.addClass('active')
    this.$parentnav.addClass('has-active')

    // activate up the road
    this.$element.parents('.brandnav').each(function () {
      $(this).parent().addClass('active')
    })

    var shownEvent = $.Event('shown.tc.brandnav', {
      target: this.$element,
      relatedTarget: this.$parentnav
    })

    if ($.support.transition) {
      this.$parentnav
        .one('tcTransitionEnd', function () {
          setTimeout(function () {
            that.$main.trigger(shownEvent)
            that.$body.css('overflow-x', '')
          })
        }).emulateTransitionEnd(BrandNav.TRANSITION_DURATION)
    } else {
      that.$body.css('overflow-x', '')
    }
  }

  BrandNav.prototype.hide = function () {

    var that = this

    var hideEvent = $.Event('hide.tc.brandnav', {
      target: this.$parentnav,
      relatedTarget: this.$element
    })

    this.$main.trigger(hideEvent)
    if (hideEvent.isDefaultPrevented()) return

    this.$body.css('overflow-x', 'hidden')
    this.$parentnav.removeClass('has-active')

    var hiddenEvent = $.Event('hidden.tc.brandnav', {
      target: this.$parentnav,
      relatedTarget: this.$element
    })

    if ($.support.transition) {
      this.$parentnav
        .one('tcTransitionEnd', function () {
          that.$parent.removeClass('active')
          that.$body.css('overflow-x', '')
          setTimeout(function () {
            that.$main.trigger(hiddenEvent)
          })
        }).emulateTransitionEnd(BrandNav.TRANSITION_DURATION)
    } else {
      this.$parent.removeClass('active')
      that.$body.css('overflow-x', '')
    }
  }

  function getSiblingNav($this) {
    var selector = $this.attr('data-target')

    if (!selector) {
      selector = $this.attr('href')
      selector = selector && /#[A-Za-z]/.test(selector) && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
    }

    var $parent = selector && $(selector)

    return $parent && $parent.length ? $parent : $this.siblings('.brandnav')
  }

  function getMain($this) {
    return $this.closest('.brandnav-lvl-1').last()
  }

  function getCurrentFromTarget($target) {
    return $target.find('.active > .brandnav').last()
  }

  // BRANDNAV PLUGIN DEFINITION
  // =======================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.brandnav')

      if (!data) $this.data('tc.brandnav', (data = new BrandNav(this)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.brandnav

  $.fn.brandnav = Plugin
  $.fn.brandnav.Constructor = BrandNav


  // NOTIFICATION NO CONFLICT
  // =================

  $.fn.brandnav.noConflict = function () {
    $.fn.brandnav = old
    return this
  }

  // NOTIFICATION DATA-API
  // ==============

  var closeCurrent = function (e) {
    e.preventDefault()
    var $target = getSiblingNav($(this))
    var $activeNav = getCurrentFromTarget($target)
    Plugin.call($activeNav, 'hide')
  }

  function clearMenus(e) {
    if (e && e.which === 3) return

    $(navOpen).each(function () {
      var $trigger = $(this)
      var $target = getSiblingNav($trigger)
      var $main = getMain($target)
      var $parent = $main.parent()

      if (!$parent.hasClass('active')) return

      if (e && e.type == 'click' && $.contains($main[0], e.target)) return

      if (e.isDefaultPrevented()) return

      $parent.find('.brandnav').each(function () {
        var $nav = $(this)
        $nav.removeClass('has-active')
        $nav.parent().removeClass('active')
      })
    })
  }

  var clickHandler = function (e) {
    e.preventDefault()
    var $target = getSiblingNav($(this))
    Plugin.call($target, 'show')
  }

  $(document)
    .on('click.tc.brandnav.data-api', clearMenus)
    .on('click.tc.brandnav.data-api', navOpen, clickHandler)
    .on('click.tc.brandnav.data-api', navClose, closeCurrent)
    .on('click.tc.brandnav.data-api', navCancel, clearMenus)

}(window.jQuery);
