+function ($) {
  'use strict';

  var formset = '.form-checkbox-set'
  var Checkbox = function (element, options) {
    this.options =
      this.$element = null

    this.init(element, options)
  }

  Checkbox.DEFAULTS = {
    template: '<div tabindex="0" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">' +
      '&nbsp;' + // important for screenreader
      '<span class="border"></span>' +
      '<span class="check" role="presentation"></span>' +
      '</div>'
  }

  Checkbox.prototype.init = function (element, options) {
    var $e = this.$element = $(element)
    this.options = this.getOptions(options)
    var $checkbox = this.checkbox()

    $e.before($checkbox)
    $e.addClass('hidden')

    $e.on('change.tc.checkbox', function (e) {
      if ($e.is(':checked')) {
        $checkbox.addClass('checked')
          .attr('aria-checked', 'true')
      } else {
        $checkbox.removeClass('checked')
          .attr('aria-checked', 'false')
      }
    })

    $checkbox.parents(formset).on('click.tc.checkbox', function (e) { // IE8 label click support
      if ($(e.target).is('label') || $checkbox[0] === $(e.target).closest('.form-checkbox-js')[0]) {
        $e.trigger('click')
        return false
      }

      return !$checkbox.is('.disabled, :disabled')
    })

    $checkbox.on('keyup.tc.checkbox', function (e) {
      if ($checkbox.is(':focus'))
        $checkbox.addClass('focus')
    })

    $checkbox.on('keydown.tc.checkbox', function (e) {
      if (e.altkey || e.ctrlKey || e.shiftKey) {
        return true
      }

      if (e.which == 32) {
        $checkbox.trigger('click')
        e.stopPropagation()
        return false
      }

      return true
    })

    $checkbox.on('keypress.tc.checkbox', function (e) {
      if (e.altkey || e.ctrlKey || e.shiftKey) {
        return true
      }

      if (e.which == 32) {
        e.stopPropagation()
        return false
      }

      return true
    })

    $checkbox.on('blur.tc.checkbox', function (e) {
      $checkbox.removeClass('focus')
    })

    if ($e.is(':checked')) {
      $checkbox.addClass('checked')
        .attr('aria-checked', 'true')
    }

    if ($e.attr('tabindex')) {
      $checkbox.attr('tabindex', $e.attr('tabindex'))
    }

    if ($e.is(':disabled') || $e.parents('fieldset').is(':disabled')) {
      this.disable()
    }
  }

  Checkbox.prototype.disable = function () {
    var $e = this.$element
    var $checkbox = this.checkbox()

    $checkbox.attr('aria-disabled', true)
      .attr('tabindex', '-1')
      .addClass('disabled')

    $e.parents(formset).addClass('disabled')
  }

  Checkbox.prototype.enable = function () {
    var $e = this.$element
    var $checkbox = this.checkbox()

    var tabindex = '0';
    if ($e.attr('tabindex')) {
      tabindex = $e.attr('tabindex')
    }

    $checkbox.attr('aria-disabled', false)
      .attr('tabindex', tabindex)
      .removeClass('disabled')

    $e.parents(formset).removeClass('disabled')
  }

  Checkbox.prototype.getDefaults = function () {
    return Checkbox.DEFAULTS
  }

  Checkbox.prototype.getOptions = function (options) {
    options = $.extend({}, this.getDefaults(), this.$element.data(), options)
    return options
  }

  Checkbox.prototype.checkbox = function () {
    return this.$checkbox = this.$checkbox || $(this.options.template)
  }

  // CHECKBOX PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.checkbox')
      var options = typeof option == 'object' && option

      if (!data)
        $this.data('tc.checkbox', (data = new Checkbox(this, options)))
      if (typeof option == 'string')
        data[option]()
    })
  }

  var old = $.fn.checkbox

  $.fn.checkbox = Plugin
  $.fn.checkbox.Constructor = Checkbox


  // CHECKBOX NO CONFLICT
  // ====================

  $.fn.checkbox.noConflict = function () {
    $.fn.checkbox = old
    return this
  }

}(window.jQuery);
