+function ($, window) {
  'use strict';

  var formset = '.form-radio-set'
  var SelectBox = function (element, options) {
    this.options  =
    this.$element = null

    this.init(element, options)
  }

  SelectBox.DEFAULTS = {
    template:
            '<div class="form-select-js" tabindex="-1">' +
              '<input type="text" class="form-select-js-choice-input" role="combobox" aria-autocomplete="list" aria-readonly="true" tabindex="0"/>' +
              '<button type="button" class="form-select-js-choice" tabindex="-1"></button>' +
              '<div class="form-select-js-option-scroll-wrapper" tabindex="-1">' +
                '<ul class="form-select-js-options" role="listbox" aria-expanded="true"></ul>' +
              '</div>' +
            '</div>',
    optionTemplate: '<li></li>',
    idPrefix: 'select-',
    maxItems: 25,
    appendToBody: true
  }

  SelectBox.prototype.init = function (element, options) {
    var $e         = this.$element = $(element)
    this.options   = this.getOptions(options)
    var $select    = this.select()
    var $scrollwrapper = this.scrollwrapper()
    var $textinput = this.textinput()
    var $choice    = this.choice()
    var $document  = $(document)
    var selectboxPrototype = this

    // only selectbox can be replaced
    if (!$e.is('select')) return

    // only non multiple selectbox is supported
    if ($e.is('[multiple]')) return

    // only no sized selectbox is supported
    if ($e.is('[size]') && parseInt($e.attr('size')) > 1) {
      return
    }

    this.setIds()

    this.createOptions()

    // render element
    $e.before($select)

    // sync with original
    this.sync()
    $e.on('change', $.proxy(function (e) {
      this.sync()
    }, this))

    if ($e.is(':disabled')) {
      $select.attr('aria-disabled', true)
      $textinput.prop('disabled', true)
    }

    if ($.support.mobile) {
      return this.applyNativeBehaviour()
    } else {
      $e.addClass('hidden')
    }
    var originalId = $e.attr('id')
    if (originalId){
      var orgLbl = $('[for="' + originalId + '"]')
      if (orgLbl){
//        $select.attr('title', (orgLbl.attr('title') || (orgLbl.text() + ' Select')) + (orgLbl.attr('alt') ? ' '+orgLbl.attr('alt') : ''))
        if (!orgLbl.attr('id'))
          orgLbl.attr('id', this.getId() + '-label')
        $textinput.attr('aria-labelledby', orgLbl.attr('id'))
      }
    }

    // hide all on document interaction
    var autoClose = function (e) {

      var $target = $(e.target).parents('.form-select-js')
      var $target2 = $(e.target).parents('.form-select-js-option-scroll-wrapper')

      if ($target[0] !== $select[0] && $target2[0] !== $scrollwrapper[0]) { // hide if not over this list of element
        return selectboxPrototype.hide(false); // do not focus after autoclose to prevent scroll issues
      }

      var $optionList = $(e.target).parent()
      if ($optionList.hasClass('form-select-js-options')) {

        var $scrollWarpper = $optionList.parent()
        var pos = $scrollWarpper.scrollTop()
        var delta = e.originalEvent.wheelDelta ? e.originalEvent.wheelDelta * -1 : e.originalEvent.delta
        var direction = (e.originalEvent.deltaY || e.originalEvent.wheelDelta * -1) > 0 ? 1 : -1
        var maxPos = $optionList.height() - $scrollWarpper.height()

        if (delta) {
          var newPos = Math.max(0, Math.min(pos + delta, maxPos))
          $scrollWarpper.scrollTop(newPos)

          e.stopImmediatePropagation()
          e.preventDefault()
        }

        if ((pos <= 0 && direction === -1) || (pos >= maxPos && direction === 1)) {
          e.stopImmediatePropagation()
          e.preventDefault()
        }
      }

    }

    $document.on('click touchstart mousewheel wheel scroll', autoClose)
    $choice.parents().on('mousewheel wheel scroll', autoClose)
    $(window).on('resize mousewheel wheel scroll', autoClose) // otherwise positions/dimensions will go crazy

    $choice.on('click', $.proxy(this.toggle, this))
  }

  SelectBox.prototype.setIds = function () {
    var id = this.getId()

    this.select().attr('id', id)
    this.optionlist().attr('id', id + '-list')
    this.textinput().attr('aria-owns', id + '-list')
            .attr('aria-labelledby', id + '-label')
  }

  // set original select on top so that mobile devices touch
  SelectBox.prototype.applyNativeBehaviour = function () {
    var $select = this.select()
    var $choice    = this.choice()
    var pos = $select.position()
    var dimensions = { width: $select.width(), height: $select.height() }

    // apply native opening to new select
    $choice.on('click', $.proxy(this.openNative, this))

    // try to position native element over new
    this.$element.css({
      display: 'block',
      visibility: 'visible',
      position: 'absolute',
      top: pos.top,
      left: pos.left,
      width: dimensions.width,
      height: dimensions.height,
      opacity: 0,
      'z-index': 99999,
      '-webkit-appearance': 'menulist-button'
    })
  }

  SelectBox.prototype.openNative = function () {
    var elem = this.$element;
    if (document.createEvent) {
      var e = document.createEvent('MouseEvents')
      e.initMouseEvent('mousedown', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
      elem[0].dispatchEvent(e)
    } else if (elem[0].fireEvent) {
      elem[0].fireEvent('onmousedown')
    }
  }

  SelectBox.prototype.sync = function () {
    var $choice = this.choice()
    var $optionlist = this.optionlist()
    var $textinput = this.textinput()

    $choice.text(this.$element.find('option:selected').text())
    var oid = $optionlist.find('.selected').attr('id')
    $textinput.attr('aria-activedescendant', oid)
  }

  SelectBox.prototype.hoverOption = function ($option) {
    if ($option.attr('aria-disabled') === 'true') return
    $option.siblings().removeClass('hover')
    $option.addClass('hover')
  }

  SelectBox.prototype.selectOption = function ($option) {
    if ($option.attr('aria-disabled') === 'true') return
    $option.siblings().removeClass('selected')
    $option.addClass('selected')
  }

  SelectBox.suppressMouseInteractionAfterViewUpdate = false
  SelectBox.prototype.setSelectedOption = function ($option, force) {
    var $e              = this.$element
    var $optionlist     = this.optionlist()
    var $options        = $optionlist.children()
    var $currentOption  = $options.filter('.selected')

    if ($option !== $currentOption || force) {
      this.hoverOption($option)
      this.selectOption($option)
      $e[0].selectedIndex = $options.index($option)
      $e.trigger('change')

      this.updateScrollView()
      SelectBox.suppressMouseInteractionAfterViewUpdate = true
    }
  }

  SelectBox.prototype.hasOriginalOptions = function () {
    return this.getOriginalOptions().length > 0
  }

  SelectBox.prototype.getOriginalOptions = function () {
    return this.$element.children()
  }

  SelectBox.prototype.createOptions = function () {
    var self        = this
    var $optionlist = this.optionlist()
    var $children   = this.getOriginalOptions()
    var $textinput  = this.textinput()
    var id          = this.getId()
    var idcount     = 0

    $optionlist.empty()
    $children.each(function () {
      var originalOption = $(this)
      var classes = []

      var disabled = originalOption.is(':disabled')
//      if (disabled) classes.push('disabled')
      if (originalOption.is(':selected')) classes.push('selected')

      $optionlist.append($(self.options.optionTemplate, {
        html: originalOption.html(),
        'data-value': originalOption.val(),
        'class': classes.join(' '), // class must be in quotes to prevent IE8 preserved keyword bug
        role: 'option',
        tabindex: '-1',
        id: id + '-option-' + (++idcount),
        'aria-disabled': disabled
      }))
    })

    var oid = $optionlist.find('.selected').attr('id')
    $textinput.attr('aria-activedescendant', oid)

    $optionlist.children()
            .on('mouseenter.tc.selectbox.option.data-api', $.proxy(function (e) {
              e.preventDefault()

              // avoid mouseselection while using arrowkeys while moving area
              if (SelectBox.suppressMouseInteractionAfterViewUpdate)
                return SelectBox.suppressMouseInteractionAfterViewUpdate = false

              this.hoverOption($(e.currentTarget))
            }, this))
            .on('click.tc.selectbox.option.data-api', $.proxy(function (e) {
              e.preventDefault()
              if ($(e.currentTarget).is('[aria-disabled="true"]')) return
              this.setSelectedOption($(e.currentTarget), true)
              this.hide()
            }, this))
  }

  SelectBox.prototype.getVisibleItemsNum = function () {
    var $select = this.select()
    var $scrollwrapper = this.scrollwrapper()
    var rowHeight = this.measureRowHeight()
    var visibleItems = Math.min(this.options.maxItems, $scrollwrapper.find('li').length)
    var pageHeightMax = Math.min(($(window).height() - $select.outerHeight()) * 0.5, visibleItems * rowHeight)
    var visibleItemsMax = Math.floor(pageHeightMax / rowHeight)
    return Math.max(1, visibleItemsMax)
  }

  SelectBox.prototype.measureRowHeight = function () {
    var $scrollwrapper = this.scrollwrapper()
    return $scrollwrapper.find('li:first').outerHeight()
  }

  SelectBox.prototype.measureScrollwrapperDimensions = function () {
    var $choice = this.choice()
    var $scrollList = this.optionlist()
    var rowHeight = this.measureRowHeight()
    var totalHeight = Math.max(rowHeight, Math.min($scrollList.height(), this.getVisibleItemsNum() * rowHeight))
    var $scrollWrapper = $scrollList.parent()

    return {
      'min-width': $choice.outerWidth(),
      height: totalHeight + Number($scrollWrapper.css('border-top-width').replace(/px/, '')) + Number($scrollWrapper.css('border-bottom-width').replace(/px/, ''))
    }
  }

  SelectBox.prototype.getCalculatedScrollwrapperOffset = function () {
    var $choice = this.choice()
    var scrollwrapperDimensions = this.measureScrollwrapperDimensions()
    var offset = { left: $choice.offset().left }

    // placement
    if ($choice.offset().top + $choice.outerHeight() - $(window).scrollTop() + scrollwrapperDimensions.height > $(window).height()) {
      // above
      offset.top = $choice.offset().top - $(window).scrollTop() - scrollwrapperDimensions.height - ($choice.outerHeight() - $choice.height())
    } else {
      // below
      offset.top = $choice.offset().top + $choice.outerHeight() - $(window).scrollTop()
    }

    return offset
  }

  SelectBox.prototype.show = function () {
    var $select         = this.select()
    var $textinput      = this.textinput()
    var $scrollwrapper  = this.scrollwrapper()
    var $optionlist     = this.optionlist()

    if (this.isDisabled()) return

    if (!this.hasOriginalOptions()) return

    this.createOptions()

    $textinput.focus()
    $select.addClass('in')
    $optionlist.attr('aria-expanded', 'true')

    var dimensions = this.measureScrollwrapperDimensions()
    var offset = this.getCalculatedScrollwrapperOffset()

    // place scrollwrapper to body
    if (this.options.appendToBody) {
      $('body').append($scrollwrapper)
    }

    $scrollwrapper.css(dimensions)
            .css(offset) // set by css to prevent margin-top
            .css('display', 'block')

    this.updateScrollView()
  }

  SelectBox.prototype.isOpened = function () {
    return this.select().hasClass('in')
  }

  SelectBox.prototype.hide = function (focus) {
    var $select = this.select()
    var $textinput = this.textinput()
    var $scrollwrapper  = this.scrollwrapper()

    if (this.isDisabled()) return

    if ($select.hasClass('in')) $select.removeClass('in')
    $scrollwrapper.css('display', '')

    // reappend to selectjs after use
    if (this.options.appendToBody) {
      $select.append($scrollwrapper)
    }

    var $optionlist = this.optionlist()
    $optionlist.attr('aria-expanded', 'false')
    if (focus !== false) $textinput.focus()
  }

  SelectBox.prototype.isDisabled = function () {
    return this.select().attr('aria-disabled') === 'true'
  }

  SelectBox.prototype.disable = function () {
    var $e = this.$element
    var $select = this.select()
    var $textinput = this.textinput()

    $e.attr('aria-disabled', true)
    $select.attr('aria-disabled', true)
    $textinput.addClass('disabled')

    $e.parents(formset).addClass('disabled')
  }

  SelectBox.prototype.enable = function () {
    var $e = this.$element
    var $select = this.select()
    var $textinput = this.textinput()

    $e.attr('aria-disabled', false)
    $select.attr('aria-disabled', false)
    $textinput.removeClass('disabled')

    $e.parents(formset).removeClass('disabled')
  }

  SelectBox.prototype.toggle = function () {
    if (this.isDisabled()) return
    this.isOpened() ? this.hide() : this.show()
  }

  SelectBox.prototype.getDefaults = function () {
    return SelectBox.DEFAULTS
  }

  SelectBox.prototype.getOptions = function (options) {
    options = $.extend({}, this.getDefaults(), this.$element.data(), options)
    return options
  }

  SelectBox.instanceCounter = 0
  SelectBox.prototype.getId = function () {
    return this.id = this.id || this.options.idPrefix + (++SelectBox.instanceCounter)
  }

  SelectBox.prototype.scrollwrapper = function () {
    return this.$scrollwrapper = this.$scrollwrapper || this.select().find('.form-select-js-option-scroll-wrapper')
  }

  SelectBox.prototype.optionlist = function () {
    return this.$optionlist = this.$optionlist || this.select().find('.form-select-js-options')
  }

  SelectBox.prototype.choice = function () {
    return this.$choice = this.$choice || this.select().find('.form-select-js-choice')
  }

  SelectBox.prototype.textinput = function () {
    return this.$textinput = this.$textinput || this.select().find('.form-select-js-choice-input')
  }

  SelectBox.prototype.select = function () {
    return this.$select = this.$select || $(this.options.template)
  }

  SelectBox.prototype.keyboardHandler = function (e) {
    var $this = $(this)
    var $elem = $this.next()
    var selectBox = $elem.data('tc.selectbox')
    var $textinput = selectBox.textinput()
    var $scrollWrapper = selectBox.scrollwrapper()
    var isActive = $this.hasClass('in')

    var navigationKeys = [
      13, // KeyBoard.ENTER
      27, // KeyBoard.ESCAPE
      33, // KeyBoard.PAGE_UP
      34, // KeyBoard.PAGE_DOWN
      35, // KeyBoard.END
      36, // KeyBoard.HOME
      37, // KeyBoard.LEFT
      38, // KeyBoard.UP
      39, // KeyBoard.RIGHT
      40  // KeyBoard.DOWN
    ]

    // respect tab-navigation
    if (e.keyCode === 9) // KeyBoard.TAB
      return selectBox.hide()

    if (selectBox.isDisabled()) return

    // clear textinput if it's not an 'alpha-numeric' input
    if (e.keyCode < 32) // KeyBoard.SPACE
      $textinput.val('')

    // open on SPACE, but only if it's the first input
    if (e.keyCode === 32 && $textinput.val() === '') { // KeyBoard.SPACE
      e.preventDefault()
      e.stopPropagation()
      return selectBox.toggle()
    }

    // do nothing else if it's not a valid navigation key
    if (!(new RegExp('^(' + navigationKeys.join('|') + ')$')).test(e.keyCode))
      return

    e.preventDefault()
    e.stopPropagation()
    SelectBox.suppressMouseInteractionAfterViewUpdate = true

    // toggle on ENTER
    if (e.keyCode === 13 || (e.altKey && (e.keyCode === 38 || e.keyCode === 40))) //  KeyBoard.ENTER,  KeyBoard.UP,  KeyBoard.DOWN
      return selectBox.toggle()

    // only close on ESCAPE
    if (e.keyCode === 27) // KeyBoard.ESCAPE
      return selectBox.hide()

    // now go for it ...
    var desc = 'li:not([aria-disabled="true"])'
    var $itemsEnabled = $scrollWrapper.find(desc)

    if (!$itemsEnabled.length) return

    var indexEnabled = $itemsEnabled.index($itemsEnabled.filter('.selected'))
    if (indexEnabled === -1) {
      var $items = $scrollWrapper.find('li')
      var tempIndex = $items.index($items.filter('.selected'))
      while (indexEnabled === -1 && --tempIndex >= 0)
        indexEnabled = $itemsEnabled.index($items.eq(tempIndex))

      if (indexEnabled === -1) {
        tempIndex = $items.index($items.filter('.selected'))
        var len = $items.length
        while (indexEnabled === -1 && ++tempIndex < len)
          indexEnabled = $itemsEnabled.index($items.eq(tempIndex))
        indexEnabled -= 0.5
      } else {
        indexEnabled += 0.5
      }
    }

    if (e.keyCode === 33 || e.keyCode === 34) { // KeyBoard.PAGE_UP, KeyBoard.PAGE_DOWN

      if (selectBox.isOpened()){
        var pageTopY = $scrollWrapper.scrollTop()
        var pageBottomY = pageTopY + $scrollWrapper.height()
        var visibleItemsNum = selectBox.getVisibleItemsNum()

        // find top most of the visible items
        var first = 0
        while (first < $itemsEnabled.length && pageTopY > $itemsEnabled[first].offsetTop) {
          first++
        }

        // find last visible item
        var last = first
        while (last < $itemsEnabled.length && $itemsEnabled[last].offsetTop + $itemsEnabled[last].offsetHeight < pageBottomY) {
          last++
        }

        if (e.keyCode === 33) { // KeyBoard.PAGE_UP
          indexEnabled = Math.ceil((indexEnabled !== first) ? first : indexEnabled - visibleItemsNum)
        } else {
          indexEnabled = (indexEnabled !== last) ? last : indexEnabled + visibleItemsNum
        }
      } else {
        indexEnabled += (e.keyCode === 33 ? -1 : 1) * 3 // 33 = KeyBoard.PAGE_UP
      }

    }
    var indexEnabledPrev = indexEnabled

    if (e.keyCode === 38) indexEnabled -= 1 // KeyBoard.UP
    if (e.keyCode === 40) indexEnabled += 1 // KeyBoard.DOWN
    if (e.keyCode === 37 && !isActive) indexEnabled -= 1 // KeyBoard.LEFT
    if (e.keyCode === 39 && !isActive) indexEnabled += 1 // KeyBoard.RIGHT
    if (e.keyCode === 36) indexEnabled = 0 // KeyBoard.HOME
    if (e.keyCode === 35) indexEnabled = $itemsEnabled.length - 1 // KeyBoard.END

    indexEnabled = Math.max(0, Math.min(indexEnabled, $itemsEnabled.length - 1))

    if (!~indexEnabled) indexEnabled = 0

    if (indexEnabled % 1) {
      if (indexEnabledPrev < indexEnabled) --indexEnabled
      indexEnabled = Math.round(indexEnabled)
    }

    selectBox.setSelectedOption($itemsEnabled.eq(indexEnabled))
  }

  SelectBox.prototype.textInputChangeHandler = function (e) {

    var $this = $(this)
    var $elem = $this.next()
    var selectBox = $elem.data('tc.selectbox')
    var $textinput = selectBox.textinput()
    var $scrollWrapper = selectBox.scrollwrapper()

    // try to find something that makes sense .... seriously

    // but first of all - clear text input value after 1000ms
    clearTimeout($.data(this, 'tiClearTimer'))
    $.data(this, 'tiClearTimer', setTimeout(function () {
      this.previousSearchText = ''
      $textinput.val('')
    }, 1000))
    var lastChar = String.fromCharCode(e.keyCode)
    var searchText = ($textinput.val().toString() + (lastChar !== this.previousSearchText ? lastChar : '')).toLowerCase()

    if (searchText === '') return

    var desc = 'li:not([aria-disabled="true"])'
    var $itemsEnabled = $(desc, $scrollWrapper)
    if (!$itemsEnabled.length) return

    var currentIndex = $itemsEnabled.index($itemsEnabled.filter('.selected'))

    var matchingIndex = -1
    if (searchText.length > 1)
      matchingIndex = selectBox.findNextOptionByText($itemsEnabled, searchText, currentIndex - 1)
    if (matchingIndex !== -1)
      return selectBox.setSelectedOption($itemsEnabled.eq(matchingIndex))

    if (lastChar && lastChar !== '') {
      matchingIndex = selectBox.findNextOptionByText($itemsEnabled, lastChar, currentIndex)
      if (matchingIndex !== -1)
        return selectBox.setSelectedOption($itemsEnabled.eq(matchingIndex))
    }
    this.previousSearchText = searchText

  }

  SelectBox.prototype.findNextOptionByText = function ($itemsEnabled, text, startIndex) {

    var needle = text.toLowerCase()
    if (needle === '')
      return -1

    var firstIndex = -1
    var nextIndex = -1

    $itemsEnabled.each(function (idx) {
      if ($(this).text().toLowerCase().indexOf(needle) === 0) {
        if (firstIndex === -1) firstIndex = idx // hit
        if (nextIndex === -1 && idx > startIndex) return nextIndex = idx
      }
    })

    return Math.max(firstIndex, nextIndex)
  }

  SelectBox.prototype.focusHandler = function (e) {
    var $selectBox = $(this).parent()
    e.type === 'focusin' ? $selectBox.addClass('focus') : $selectBox.removeClass('focus')
  }

  SelectBox.prototype.updateScrollView = function () {

    var $optionlist = this.optionlist()
    var $selected = $optionlist.find('.selected')
    if (!$selected[0]) return

    var $scrollWrapper = this.scrollwrapper()
    var scrollY = $scrollWrapper.scrollTop()
    var scrollwrapperDimensions = this.measureScrollwrapperDimensions()

    var selectionScrollY = $selected[0].offsetTop
    var selectionHeight = $selected[0].offsetHeight
    if (scrollY > selectionScrollY) {
      $scrollWrapper.scrollTop(selectionScrollY)
    } else if (scrollY + scrollwrapperDimensions.height < selectionScrollY + selectionHeight) {
      $scrollWrapper.scrollTop(selectionScrollY + selectionHeight - scrollwrapperDimensions.height)
    }
  }

  // SELECT PLUGIN DEFINITION
  // ==========================

  function Plugin (option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.selectbox')
      var options = typeof option === 'object' && option

      if (!data) $this.data('tc.selectbox', (data = new SelectBox(this, options)))
      if (typeof option === 'string') data[option]()
    })
  }

  var old = $.fn.selectbox

  $.fn.selectbox             = Plugin
  $.fn.selectbox.Constructor = SelectBox


  // SELECT NO CONFLICT
  // ====================

  $.fn.selectbox.noConflict = function () {
    $.fn.selectbox = old
    return this
  }

  // APPLY TO STANDARD DROPDOWN ELEMENTS
  // ===================================

  $(document)
    .on('keydown.tc.selectbox.data-api', '.form-select-js', SelectBox.prototype.keyboardHandler)
    .on('keypress.tc.selectbox.data-api', '.form-select-js', SelectBox.prototype.textInputChangeHandler)

    .on('focusin.tc.selectbox.data-api', '.form-select-js-choice-input', SelectBox.prototype.focusHandler)
    .on('focusout.tc.selectbox.data-api', '.form-select-js-choice-input', SelectBox.prototype.focusHandler)

}(window.jQuery, window);
