+function ($) {
  'use strict';

  // DETECT MOBILE DEVICE SUPPORT
  // ============================================================

  // Adapted from http://www.detectmobilebrowsers.com
  var ua = navigator.userAgent || navigator.vendor || window.opera

  // Checks for iOs, Android, Blackberry, Opera Mini, and Windows mobile devices
  var ismobile = (/iPhone|iPod|iPad|Silk|Android|BlackBerry|Opera Mini|IEMobile/).test(ua)

  $(function () {
    $.support.mobile = ismobile
  })

}(window.jQuery);
