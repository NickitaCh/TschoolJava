+function ($) {
  'use strict';

  // easing Functions

  // t current
  // b start
  // c change in value
  // d duration

  // ease in
  Math.easeInSine = function (t, b, c, d) {
    return -c * Math.cos(t / d * (Math.PI / 2)) + c + b
  }

  // ease out
  Math.easeOutSine = function (t, b, c, d) {
    return c * Math.sin(t / d * (Math.PI / 2)) + b
  }

  // ease in out
  Math.easeInOutSine = function (t, b, c, d) {
    return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b
  }

  Math.roundToDP = function (value, decimalPoint) {
    return Math.round(value * decimalPoint) / decimalPoint
  }

  window.rgbTohex = function (color) {
    if (/^#[0-9A-F]{6}$/i.test(color)) return color
    color = color.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/)
    return '#' + window.singleColorToHex(color[1]) + window.singleColorToHex(color[2]) + window.singleColorToHex(color[3])
  }

  window.colormatch = function (sc, ec, pr, range) {
    sc = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(sc)
    var rA = parseInt(sc[1], 16)
    var gA = parseInt(sc[2], 16)
    var bA = parseInt(sc[3], 16)

    ec = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(ec)
    var rB = parseInt(ec[1], 16)
    var gB = parseInt(ec[2], 16)
    var bB = parseInt(ec[3], 16)

    var rC = Math.round(rA + ((rB - rA) * (pr / range)))
    var gC = Math.round(gA + ((gB - gA) * (pr / range)))
    var bC = Math.round(bA + ((bB - bA) * (pr / range)))

    return '#' + window.singleColorToHex(rC) + window.singleColorToHex(gC) + window.singleColorToHex(bC)
  }

  window.singleColorToHex = function (color) {
    var hexColor = color.toString(16)
    return hexColor.length == 1 ? '0' + hexColor : hexColor
  }

  var AnimateIcn = function (element, animation, state, options) {
    this.options  =
    this.$element = null

    this.pulseOption
    this.spinOption

    this.init(element, animation, state, options)
  }

  AnimateIcn.PULSEDEFAULTS = {
    autorun: true,
    opacityMax: 1,
    opacityMin: 0.4,
    opacity: true,
    pulseColor: 'e20074',
    color: false,
    play: false,
    running: false,
    init: false,
    time: 1220,
    stepTime: 0,
    ca: 0,
    cv: 0,
    range: 0
  }

  AnimateIcn.SPINDEFAULTS = {
    autorun: true,
    degrees: 360,
    time: 1500,
    direction: true,
    init: false,
    play: false,
    running: false,
    stepTime: 0,
    stepSize: 0,
    ca: 0,
    acc: 1,
    acci: 0,
    accTime: 0,
    acctype: true,
    margin: '',
    padding: ''
  }

  AnimateIcn.DEFAULTS = {
    animation: false,
    animationSpeed: 1000
  }

  AnimateIcn.prototype.init = function (element, animation, state, options) {
    var $e = this.$element = $(element)
    this.options = $.extend({ }, AnimateIcn.DEFAULTS, options)


    this.pulseOption = $.extend({ }, AnimateIcn.PULSEDEFAULTS)
    this.spinOption = $.extend({ }, AnimateIcn.SPINDEFAULTS)

    if ($e.parent().hasClass('animationWrapper') === false) {
      var padding = 'padding:' + $e.css('padding-top') + ' ' +
              $e.css('padding-right') + ' ' +
              $e.css('padding-bottom') + ' ' +
              $e.css('padding-left') + '; '
      var margin = 'margin:' + $e.css('margin-top') + ' ' +
              $e.css('margin-right') + ' ' +
              $e.css('margin-bottom') + ' ' +
              $e.css('margin-left') + '; '
      $($e).wrap('<div class="animationWrapper" style="display:inline-block; ' + padding + margin + '"></div>')
    }

    if (this[animation + 'Option'].autorun === true) {
      this.setAnimation(animation, 'play')
    }
  }

  AnimateIcn.prototype.pulseInit = function () {
    var $e = this.$element
    var pt = this.pulseOption
    if (pt.init === false) {
      pt.stepTime = Math.round(pt.time / (1000 / 60))
      pt.range = pt.opacityMax - pt.opacityMin
      pt.init = true
      pt.ca = 0
      pt.cv = 0
      pt.pulseInitcolor = window.rgbTohex($e.css('color'))
      pt.init = true
    }
  }

  AnimateIcn.prototype.pulse = function () {
    this.pulseInit()
    var $e = this.$element
    var pt = this.pulseOption
    var tempValue = 0

    switch (pt.play) {
      case true:
        this.spinInit()
        pt.acctype = true
        if (pt.running === false) {
          pt.running = true
          animate()
        }
        break
      case false:
        if (pt.running === true) {
          pt.running = false
        }
    }

    function animate() {
      if (pt.ca >= pt.stepTime * 2) pt.ca = 0
      tempValue = Math.easeInOutSine(pt.ca, 0, 1, pt.stepTime)
      tempValue = pt.opacityMax - Math.roundToDP(pt.range / 1 * tempValue, 100)

      if (pt.color === true)
        $($e).css('color', window.colormatch(pt.pulseInitcolor, pt.pulseColor, tempValue, 1))
      if (pt.opacity === true) $($e).css('opacity', tempValue)

      pt.ca += 1
      if (pt.running !== false) {
        window.requestAnimationFrame(function () {
          animate()
        })
      }
    }
  }

  AnimateIcn.prototype.setAnimation = function (animation, state, options) {
    var $e = this.$element
    var pt = this[animation + 'Option']

    if (options) $.merge(this[animation + 'Option'], options)

    if (state === undefined) state = 'toggle'
    console.log(pt.play + ' ' + animation + ' before')
    switch (state) {
      case 'play':
        pt.play = true
        break
      case 'pause':
        pt.play = false
        break
      case 'stop':
        pt.init = false
        this[animation + 'Init']()
        pt.play = false
        break
      case 'toggle':
        pt.play = pt.play ? false : true
        break

    }
    console.log(pt.play + ' ' + animation)
    this[animation]()
  }

  AnimateIcn.prototype.accelerration = function (animation) {
    var pt = this[animation + 'Option']

    if (pt.acci < pt.accTime && pt.acci > 0) {
      pt.acc = Math.easeInOutSine(pt.acci, 0, 1, pt.accTime)
    }

    if (pt.acci < pt.accTime && pt.acctype === true)
      pt.acci = Math.round(pt.acci + 2)
    else if (pt.acci > 0 && pt.acctype === false) pt.acci -= 0.5

    if (pt.acci === 0 && pt.acctype === false) {
      pt.running = false
    }
  }

  AnimateIcn.prototype.spinInit = function () {
    var pt = this.spinOption
    if (pt.init === false) {
      pt.stepTime = Math.round(pt.time / (1000 / 60))
      pt.stepSize = Math.round(pt.degrees / pt.stepTime)
      pt.accTime = Math.round(pt.stepTime * 0.25)
      pt.running = false
      pt.ca = 0
      pt.acc = 1
      pt.acci = 0,
      pt.init = true
    }
  }

  AnimateIcn.prototype.spin = function () {
    var $e = this.$element
    var pt = this.spinOption
    var p = this
    switch (pt.play) {
      case true:
        this.spinInit()
        pt.acctype = true
        if (pt.running === false) {
          pt.running = true
          animate()
        }
        break
      case false:
        if (pt.running === true) {
          pt.acctype = false
        }
    }

    function animate() {
      p.accelerration('spin')

      if (pt.direction === true) {
        if (pt.ca >= pt.degrees) pt.ca = pt.ca - pt.degrees
        pt.ca += Math.roundToDP(pt.stepSize * pt.acc, 10)
      } else if (pt.direction === false) {
        if (pt.ca <= -pt.degrees) pt.ca = 0 - (pt.ca + pt.degrees)
        pt.ca = Math.roundToDP(pt.ca - (pt.stepSize * pt.acc), 10)
      }

      $($e).css({ '-webkit-transform': 'rotate(' + pt.ca + 'deg)',
        '-moz-transform': 'rotate(' + pt.ca + 'deg)',
        '-ms-transform': 'rotate(' + pt.ca + 'deg)',
        '-o-transform': 'rotate(' + pt.ca + 'deg)',
        transform: 'rotate(' + pt.ca + 'deg)'
      })

      if (pt.running !== false) {
        window.requestAnimationFrame(function () {
          animate()
        })
      }
    }
  }

  AnimateIcn.prototype.callFunction = function ($e, type) {
    var callback = 'data-callback'
    var filter = 'data-callback-states'
    if ($e === undefined) $e = this.$element
    var callbackFunction = $e.attr(callback)
    var callbackFilter = $e.attr(filter)
    if (callbackFunction !== undefined) {
      if (type === 'press') window[callbackFunction].call($e, type)
      else if (callbackFilter === 'all')
        window[callbackFunction].call($e, type)
    }
  }

  AnimateIcn.prototype.mergeOptions = function (defaults, options) {
    options = options.option
    var returnObj = {}
    var settingName
    for (settingName in defaults) { returnObj[settingName] = defaults[settingName] }
    for (settingName in options) { returnObj[settingName] = options[settingName] }
    return returnObj
  }

  // AnimateIcn PLUGIN DEFINITION
  // ==========================

  function Plugin(animation, state, option) {
    var $this = $(this)
    var data = $this.data('tc.animateIcn')
    var options = typeof option == 'object' && option
    if (!data) $this.data('tc.animateIcn', (data = new AnimateIcn(this, animation, state, options)))
    else if (state && option) data.setAnimation(animation, state, option)
    else if (state) data.setAnimation(animation, state)
     // else data.setAnimation(animation, state)
     // else if (typeof option == 'string') data[option].call($this)
  }

  var old = $.fn.animateIcn

  $.fn.animateIcn = Plugin
  $.fn.animateIcn.Constructor = AnimateIcn

  // AnimateIcn NO CONFLICT
  // ====================

  $.fn.animateIcn.noConflict = function () {
    $.fn.animateIcn = old
    return this
  }

}(window.jQuery);
