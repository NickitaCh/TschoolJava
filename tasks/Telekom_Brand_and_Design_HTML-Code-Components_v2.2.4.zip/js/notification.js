+function ($) {
  'use strict';


  var dismiss = '[data-dismiss="notification"]'
  var Notification   = function (el) {
    $(el).on('click', dismiss, this.close)
  }

  Notification.VERSION = '1.0.0'

  Notification.TRANSITION_DURATION = 150

  Notification.prototype.close = function (e) {
    var $this    = $(this)
    var selector = $this.attr('data-target')

    if (!selector) {
      selector = $this.attr('href')
      selector = selector && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
    }

    var $parent = $(selector)

    if (e) e.preventDefault()

    if (!$parent.length) {
      $parent = $this.closest('.notification')
    }

    $parent.trigger(e = $.Event('close.tc.notification'))

    if (e.isDefaultPrevented()) return

    $parent.removeClass('in')

    function removeElement() {
      // detach from parent, fire event then clean up data
      $parent.detach().trigger('closed.tc.notification').remove()
    }

    $.support.transition && $parent.hasClass('fade') ?
      $parent
        .one('tcTransitionEnd', removeElement)
        .emulateTransitionEnd(Notification.TRANSITION_DURATION) :
    removeElement()
  }


  // NOTIFICATION PLUGIN DEFINITION
  // =======================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data  = $this.data('tc.notification')

      if (!data) $this.data('tc.notification', (data = new Notification(this)))
      if (typeof option == 'string') data[option].call($this)
    })
  }

  var old = $.fn.notification

  $.fn.notification             = Plugin
  $.fn.notification.Constructor = Notification


  // NOTIFICATION NO CONFLICT
  // =================

  $.fn.notification.noConflict = function () {
    $.fn.notification = old
    return this
  }


  // NOTIFICATION DATA-API
  // ==============

  $(document).on('click.tc.notification.data-api', dismiss, Notification.prototype.close)

}(window.jQuery);
