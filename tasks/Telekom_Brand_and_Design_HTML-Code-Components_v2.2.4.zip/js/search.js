+function ($) {
  'use strict';

  var Search = function (element, options) {
    this.$element = $(element)
    this.options = $.extend({}, Search.DEFAULTS, options)
    this.$trigger = $('[data-toggle="search"][href="#' + element.id + '"],' +
      '[data-toggle="search"][data-target="#' + element.id + '"]')
    this.transitioning = null

    if (this.options.toggle) this.toggle()
  }

  Search.DEFAULTS = {
    toggle: true,
    keyboard: true,
    onBlur: false
  }

  Search.TRANSITION_DURATION = 250

  Search.prototype.show = function () {
    if (this.transitioning || this.$element.hasClass('in')) return

    var startEvent = $.Event('show.tc.search')
    this.$element.trigger(startEvent)
    if (startEvent.isDefaultPrevented()) return

    this.$element
      .removeClass('search')
      .attr('aria-expanded', true)

    this.$trigger
      .attr('aria-expanded', true)
      .blur()

    this.transitioning = 1

    var complete = function () {
      this.$element
        .addClass('search in')
      this.transitioning = 0
      this.enforceFocus()
      this.escape()
      this.$element
        .trigger('shown.tc.search')

      if (this.options.onBlur === 'dismiss') {
        this.$element.on('blur.dismiss.tc.search', 'input', $.proxy(this.hide, this))
      }
    }

    if (!$.support.transition) return complete.call(this)

    this.$element
      .one('tcTransitionEnd', $.proxy(complete, this))
      .emulateTransitionEnd(Search.TRANSITION_DURATION)
  }

  Search.prototype.hide = function () {
    if (this.transitioning || !this.$element.hasClass('in')) return

    var startEvent = $.Event('hide.tc.search')
    this.$element.trigger(startEvent)

    if (startEvent.isDefaultPrevented()) return

    this.$element
      .removeClass('search in')
      .attr('aria-expanded', false)

    this.$trigger
      .attr('aria-expanded', false)

    this.transitioning = 1

    var complete = function () {
      this.transitioning = 0
      this.$element
        .addClass('search')
        .trigger('hidden.tc.search')

      this.$element.off('blur.dismiss.tc.search', 'input')
    }

    if (!$.support.transition) return complete.call(this)

    this.$element
      .one('tcTransitionEnd', $.proxy(complete, this))
      .emulateTransitionEnd(Search.TRANSITION_DURATION)
  }

  Search.prototype.toggle = function () {
    this[this.$element.hasClass('in') ? 'hide' : 'show']()
  }

  Search.prototype.enforceFocus = function () {
    this.$element.find('input').trigger('focus')
  }

  Search.prototype.escape = function () {
    if (this.$element.hasClass('in') && this.options.keyboard) {
      this.$element.on('keydown.dismiss.tc.search', $.proxy(function (e) {
        e.which == 27 && this.hide()
      }, this))
    } else if (!this.$element.hasClass('in')) {
      this.$element.off('keydown.dismiss.tc.search')
    }
  }

  function getTargetFromTrigger($trigger) {
    var href
    var target = $trigger.attr('data-target')
      || (href = $trigger.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, '') // strip for ie7

    return $(target)
  }

  // SEARCH PLUGIN DEFINITION
  // =====================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.search')
      var options = $.extend({}, Search.DEFAULTS, $this.data(), typeof option == 'object' && option)

      if (!data && options.toggle && /show|hide/.test(option)) {
        options.toggle = false
      }

      if (!data) $this.data('tc.search', (data = new Search(this, options)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.search

  $.fn.search = Plugin
  $.fn.search.Constructor = Search


  // SEARCH NO CONFLICT
  // ===============

  $.fn.search.noConflict = function () {
    $.fn.search = old
    return this
  }


  // SEARCH DATA-API
  // ============

  $(document)
    .on('click.tc.search.data-api', '[data-toggle="search"]', function (e) {
      var $this = $(this)

      if (!$this.attr('data-target')) e.preventDefault()

      var $target = getTargetFromTrigger($this)
      var data = $target.data('tc.search')
      var option = data ? 'toggle' : $this.data()

      Plugin.call($target, option)
    })

}(jQuery);
