+function ($) {
  'use strict';
  var id = 0;

  var Expandable = function (element, options) {
    this.options  =
    this.$element = $(element)
    this.init(element, options)
  }

  Expandable.DEFAULTS = {
    speed: 400,
    syncToSize: false,
    state: true,
    height: 0,
    group: undefined,
    id:''
  }

  Expandable.prototype.init = function (element, options) {
    var $e = this.$element = $(element)
    this.options = this.mergeOptions(options)
    var getOptions = this.options
    if (getOptions.group) getOptions.id = getOptions.group + '-' + id
    else getOptions.id = id
    id++
    if ($e.hasClass('expandable-hidden') === true) {
      $($e).wrap('<div id="' + getOptions.id + '" class="expanable-container expandable-hidden"></div>')
      $($e).parent().css({ height: 0, opacity: 0 })
      $($e).removeClass('expandable-hidden')
      getOptions.state = false
    } else {
      $($e).wrap('<div id="' + getOptions.id + '" class="expanable-container"></div>')
      getOptions.state = true
    }
    this.calculateHeight()
    var object = this
  }

  Expandable.prototype.calculateHeight = function () {
    var element = this.$element
    var option = this.options

    var copy = $(element).clone().attr('id', false)
                                 .css({ display:'inline-block',
                                        position:'absolute',
                                        left:'-10000px',
                                        width: $(element).parent().innerWidth()
                                      });
    $('body').append(copy);
    option.height =  copy.outerHeight(true)
    copy.remove()
  }


  Expandable.prototype.visible = function () {
    var data = this.data('tc.expandable')
    var options = data.options
    data.setVisibility(this, false)
  }


  Expandable.prototype.hidden = function () {
    var data = this.data('tc.expandable')
    var options = data.options
    data.setVisibility(this, true)
  }


  Expandable.prototype.toggleVisibility = function () {
    var data = this.data('tc.expandable')
    var options = data.options
    var eIndex = $(options.group).index()

    if (options.group !== undefined) {
      $('.' + options.group).each(function (index) {
        if (options.id != $(this).data('tc.expandable').options.id) {
          data.setVisibility($(this), true)
        }
      })
      data.setVisibility(this, false)
    } else {
      data.setVisibility(this)

    }
  }


  Expandable.prototype.setVisibility  = function ($e, state) {
    var data = $e.data('tc.expandable')
    var options = data.options
    var speed = 0
    var $parent = $($e).parent()
    if (options.syncToSize === true) speed = 1000 / options.speed * options.height
    else speed = options.speed

    if (state === undefined) state = options.state

    if (state === true) {
      $parent.stop(true,false).animate({ height: 0, opacity: 0 }, speed, function () { $parent.addClass('expandable-hidden') })
      options.state = false
    } else if (state === false) {
      $parent.removeClass('expandable-hidden')
      $parent.stop(true,false).animate({ height: options.height + 'px', opacity: 1 }, speed)
      options.state = true
    }

  }


  Expandable.prototype.getDefaults = function () {
    return Expandable.DEFAULTS
  }


  Expandable.prototype.mergeOptions = function (options) {
    options = options.option;
    var returnObj = {}
    var settingName
    var defaults = this.getDefaults();
    for (settingName in defaults) { returnObj[settingName] = defaults[settingName] }
    for (settingName in options) { returnObj[settingName] = options[settingName] }
    return returnObj;
  }

  // Expandable PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data = $this.data('tc.expandable')
      var options = typeof option == 'object' && option
      if (!data) $this.data('tc.expandable', (data = new Expandable(this, options)))
      else if (typeof option == 'string') data[option].call($this)
    })
  }

  var old = $.fn.expandable

  $.fn.expandable = Plugin
  $.fn.expandable.Constructor = Expandable

  // expanable NO CONFLICT
  // ====================

  $.fn.expandable.noConflict = function () {
    $.fn.expandable = old
    return this
  }

}(window.jQuery);
