/*!
 * Telekom Components's Gruntfile
 * Copyright 2016 Telekom AG
 */

module.exports = function (grunt) {
  'use strict';

  grunt.util.linefeed = '\n';

  var serveStatic = require('serve-static');

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    banner: '/*!\n' +
            ' * Telekom Components v<%= pkg.version %> [<%= grunt.template.today("yyyy-mm-dd") %>]\n' +
            ' * Copyright 2014-<%= grunt.template.today("yyyy") %> <%= pkg.author %>\n' +
            ' */\n',
    jqueryCheck: 'if (typeof jQuery === \'undefined\') { throw new Error(\'jQuery is required\') }\n\n',
    /**
     * The directories to delete when `grunt clean` is executed.
     */
    clean: {
      dist: 'dist',
      docs: ['docs/*.html', 'dist-docs'], // clean whole docs folder, even index.html is generated
      server: '.tmp',
      sass: '.sass-cache'
    },
    jshint: {
      options: {
        jshintrc: 'js/.jshintrc'
      },
      gruntfile: {
        src: 'Gruntfile.js'
      },
      core: {
        src: 'js/*.js'
      },
      test: {
        src: 'js/tests/unit/*.js'
      }
    },
    jscs: {
      options: {
        config: 'js/.jscsrc'
      },
      gruntfile: {
        src: '<%= jshint.gruntfile.src %>'
      },
      core: {
        src: '<%= jshint.core.src %>'
      },
      test: {
        src: '<%= jshint.test.src %>'
      }
    },
    csslint: {
      options: {
        csslintrc: 'scss/.csslintrc',
        formatters: [
          {
            id: 'csslint-xml',
            dest: 'report/csslint.xml'
          }
        ]
      },
      src: [
        'dist/css/*.css',
        '!dist/css/*.min.css',
        '!dist/css/theme-debug.css'
      ]
    },

    cssmin: {
      options: {
        // TODO: disable `zeroUnits` optimization once clean-css 3.2 is released
        compatibility: 'ie8',
        keepSpecialComments: '*',
        sourceMap: true,
        advanced: false
      },
      minifyCore: {
        src: 'dist/css/<%= pkg.name %>.css',
        dest: 'dist/css/<%= pkg.name %>.min.css'
      },
      minifyThemes: {
        files: [{
            expand: true,
            cwd: 'dist/css',
            src: ['theme-*.css', '!*.min.css'],
            dest: 'dist/css',
            ext: '.min.css'
          }]
      }
//      docs: {
//        src: [
//          'docs/assets/css/ie10-viewport-bug-workaround.css',
//          'docs/assets/css/src/pygments-manni.css',
//          'docs/assets/css/src/docs.css'
//        ],
//        dest: 'docs/assets/css/docs.min.css'
//      }
    },

    concat: {
      core: {
        options: {
          banner: '<%= banner %>\n<%= jqueryCheck %>',
          stripBanners: false
        },
        src: [
          'js/vendor/raf.js',
          'js/mobile.js',
          'js/transition.js',
          'js/radio.js',
          'js/checkbox.js',
          'js/selectbox.js',
          'js/modal.js',
          'js/notification.js',
          'js/brandnavhead.js',
          'js/brandnav.js',
          'js/collapse.js',
          'js/search.js',
//          'js/notify.js', // is in dev-state
          'js/vendor/jquery.qtip.js',
          'js/qtip-defaults.js',
          'js/totop.js',
          'js/fixation.js',
          'js/button.js',
          'js/expandable.js'
        ],
        dest: 'dist/js/<%= pkg.name %>.js'
      },
      debug: {
        options: {
          banner: '<%= banner %>\n<%= jqueryCheck %>',
          stripBanners: false
        },
        src: [
          'js/debugthingy.js'
        ],
        dest: 'dist/js/<%= pkg.name %>.debug.js'
      }
    },
    uglify: {
      core: {
        options: {
          banner: '<%= banner %>'
        },
        src: '<%= concat.core.dest %>',
        dest: 'dist/js/<%= pkg.name %>.min.js'
      }
    },
    copy: {
      assets: {
        src: 'fonts/*',
        dest: 'dist/'
      },
      styles: {
        expand: true,
        cwd: '.tmp',
        src: 'css/*',
        dest: 'dist'
      },
      components: {
        expand: true,
        cwd: 'dist/',
        src: ['css/*.min.{css,css.map}', 'js/*.min.{js,map}', 'fonts/*', 'images/*'],
        dest: 'dist-docs/'
      }
    },
    qunit: {
      options: {
        inject: 'js/tests/unit/phantom.js'
      },
      files: ['js/tests/*.html']
    },
    connect: {
      options: {
        port: 4560,
        hostname: '*',
        livereload: 35731
      },
      livereload: {
        options: {
          open: true,
          middleware: function (connect) {
            return [
              connect().use(
                      '/bower_components',
                      serveStatic('./bower_components')
                      ),
              connect().use(
                      '/assets',
                      serveStatic('./assets')
                      ),
              connect().use(
                      '/js',
                      serveStatic('./js')
                      ),
              connect().use(
                      '/fonts',
                      serveStatic('./fonts')
                      ),
              serveStatic('.tmp')
            ];
          }
        }
      },
      server: {
        options: {
          port: 3000,
          base: '.'
        }
      }
    },
    sass: {
      options: { // Target options
        style: 'expanded'
      },
      core: {
        files: {
          '.tmp/css/<%= pkg.name %>.css': 'scss/<%= pkg.name %>.scss'
        }
      },
      themes: {
        files: {
          '.tmp/css/theme-dark.css': 'scss/themes/dark-theme/theme.scss',
          '.tmp/css/theme-bevel.css': 'scss/themes/bevel-theme/theme.scss', // this is a sample case
          '.tmp/css/theme-debug.css': 'scss/themes/debug-theme/theme.scss' // this is for showing the grid
        }
      }
    },

    autoprefixer: {
      options: {
        browsers: ['last 2 versions', 'ie 8', 'ie 9']
      },
      core: {
        options: {
          map: true
        },
        src: '.tmp/css/<%= pkg.name %>.css'
      },
      themes: {
        options: {
          map: true
        },
        src: [
          '.tmp/css/theme-bevel.css',
          '.tmp/css/theme-dark.css'
        ]
      }
//      docs: {
//        src: ['docs/assets/css/src/docs.css']
//      },
//      examples: {
//        expand: true,
//        cwd: 'docs/examples/',
//        src: ['**/*.css'],
//        dest: 'docs/examples/'
//      }
    },

    scsslint: {
      allFiles: [
        'scss/{,*/,*/*/}*.{sass,scss}',
        '!scss/_normalize.scss', // except third party normalize
        '!scss/_font-faces.scss', // has it's special formatting
        '!scss/_icons.scss' // has it's special formatting
      ],
      options: {
        config: 'scss/.scss-lint.yml',
        reporterOutput: 'report/scss-lint-report.xml'
      }
    },
    usebanner: {
      dist: {
        options: {
          position: 'top',
          banner: '<%= banner %>'
        },
        files: {
          src: [
            'dist/css/<%= pkg.name %>.css',
            'dist/css/<%= pkg.name %>.min.css',
            'dist/css/theme-bevel.css',
            'dist/css/theme-bevel.min.css',
            'dist/css/theme-debug.css',
            'dist/css/theme-debug.min.css',
            'dist/css/theme-dark.css',
            'dist/css/theme-dark.min.css'
          ]
        }
      }
    },
    jekyll: {
      docs: {
        options: {// Target options
          config: 'docs/_config.yml'
        }
      },
      server: {
        options: {
          config: 'src-test/_config.yml',
          dest: '.tmp/'
        }
      }
    },
    watch: {
      options: {
        livereload: true
      },
      src: {
        files: '<%= jshint.core.src %>',
        tasks: ['jshint:core', 'qunit']
      },
      test: {
        files: '<%= jshint.test.src %>',
        tasks: ['jshint:test', 'qunit']
      },
      sass: {
        files: [
          'scss/{,*/,*/*/}*.{scss,sass}'
        ],
        tasks: ['sass']
      },
      html: {
        files: 'src-test/{,*/,*/*/}*.{html,yml}',
        tasks: ['jekyll:server']
      },
      livereload: {
        options: {
          livereload: '<%= connect.options.livereload %>'
        },
        files: [
          '.tmp/{,*/}*.html',
          '.tmp/css/{,*/}*.css'
        ]
      }
    },
    sed: {
      versionNumber: {
        pattern: (function () {
          var old = grunt.option('oldver');
          return old ? RegExp.quote(old) : old;
        })(),
        replacement: grunt.option('newver'),
        recursive: true
      }
    },
    dtdocs: {
      test: {
        options: {
          markdownOptions: {
//            gfm: true
//            highlight: function(code, lang) { // done in dt-doc-generator
//                return '{% highlight ' + (lang || 'html') + ' %}' + code + '{% endhighlight %}';
//            }
          }
        },
        cwd: 'hallo',
        files: [
          {
            title: 'Einführung',
            src: [
              'README.md',
              'status.md'
            ],
            dest: 'docs/index.html'
          },
          {
            title: 'Grundlagen',
            src: [
              'scss/components.md',
              'scss/_normalize.md',
              'scss/_font-faces.md'
            ],
            dest: 'docs/basics.html'
          },
          {
            title: 'Grid',
            src: ['scss/_grid.md'],
            dest: 'docs/grid.html'
          },
          {
            title: 'Typografie',
            src: ['scss/_type.md'],
            dest: 'docs/type.html'
          },
          {
            title: 'Icons',
            src: ['scss/_icons.md'],
            dest: 'docs/icons.html'
          },
          {
            title: 'Badges',
            src: ['scss/_badges.md'],
            dest: 'docs/badges.html'
          },
          {
            title: 'Tabellen',
            src: ['scss/_tables.md'],
            dest: 'docs/tables.html'
          },
          {
            title: 'Buttons',
            src: ['scss/_button.md'],
            dest: 'docs/buttons.html'
          },
          {
            title: 'Formulare',
            src: [
              'scss/_forms.md',
              'scss/_checkbox.md',
              'scss/_radio.md',
              'scss/_select.md'
            ],
            dest: 'docs/forms.html'
          },
          {
            title: 'Bilder',
            src: ['scss/_images.md'],
            dest: 'docs/images.html'
          },
          {
            title: 'Benachrichtigungen',
            src: ['scss/_notifications.md'],
            dest: 'docs/notifications.html'
          },
          {
            title: 'Content-Listen',
            src: ['scss/_content-list.md'],
            dest: 'docs/content-list.html'
          },
          {
            title: 'Header',
            src: ['scss/_header.md'],
            dest: 'docs/header.html'
          },
          {
            title: 'Footer',
            src: ['scss/_footer.md'],
            dest: 'docs/footer.html'
          },
          {
            title: 'Breadcrumb',
            src: ['scss/_breadcrumb.md'],
            dest: 'docs/breadcrumb.html'
          },
          {
            title: 'Ppagination',
            src: ['scss/_pagination.md'],
            dest: 'docs/pagination.html'
          },
          {
            title: 'Pager',
            src: ['scss/_pager.md'],
            dest: 'docs/pager.html'
          },
          {
            title: 'Button',
            src: ['scss/_jsbutton.md'],
            dest: 'docs/jsbutton.html'
          },
          {
            title: 'Expandable',
            src: ['scss/_expandable.md'],
            dest: 'docs/expandable.html'
          },
          {
            title: 'ToTop',
            src: ['scss/_totop.md'],
            dest: 'docs/totop.html'
          },
          {
            title: 'Modal',
            src: ['scss/_modal.md'],
            dest: 'docs/modal.html'
          },
          {
            title: 'QTip',
            src: ['scss/_qtip.md'],
            dest: 'docs/qtip.html'
          },
          {
            title: 'Helfer',
            src: [
              'scss/_helper.md',
              'scss/_accessibility.md',
              'scss/_brandcolor.md'
            ],
            dest: 'docs/helper.html'
          },
          {
            title: 'SEO und Accessibility',
            src: ['scss/_accessibility-seo.md'],
            dest: 'docs/accessibility-seo.html'
          },
          {
            title: 'SCSS',
            src: ['scss/_functions.md'],
            dest: 'docs/scss.html'
          }
        ]
      }
    },
    validation: {
      files: {
        options: {
//          serverUrl: 'https://jigsaw.w3.org/css-validator/validator',
          path: 'report/validation-status.json',
          reportpath: 'report/validation-report.json',
          charset: 'utf-8',
          doctype: 'HTML5',
          failHard: true,
          reset: true,
          relaxerror: [
            'The itemprop attribute was specified, but the element is not a property of any item.' // we have only examples in this case
          ]
        },
        src: ['dist-docs/**/*.html']
      }
    },
    accessibility: {
      options: {
        accessibilityLevel: 'WCAG2A',
        reportType: 'txt',
        reportLocation: 'report/accessibility-report',
        force: true,
        reportLevels: {
          notice: false,
          warning: false,
          error: true
        }
      },
      test: {
        src: [
//          'dist-docs/accessibility-seo.html'
//          'dist-docs/badges.html'
//          'dist-docs/basics.html'
//          'dist-docs/buttons.html'
//          'dist-docs/content-list.html'
//          'dist-docs/forms.html'
//          'dist-docs/grid.html'
//          'dist-docs/helper.html'
//          'dist-docs/icons.html'
//          'dist-docs/images.html'
//          'dist-docs/index.html'
//          'dist-docs/jsmodules.html'
//          'dist-docs/modules.html'
//          'dist-docs/notifications.html'
//          'dist-docs/scss.html'
//          'dist-docs/tables.html'
//          'dist-docs/type.html'
//          'dist-docs/*.html'
        ]
      }
    }
  });

  require('load-grunt-tasks')(grunt, { scope: 'devDependencies' });
  require('time-grunt')(grunt);
  require('./grunt/dt-doc-generator.js')(grunt);

  // Test Task
  grunt.registerTask('test', ['scsslint', 'dist-css', 'csslint', 'jshint', 'jscs', 'qunit']);

  // WCAG Task
  grunt.registerTask('wcag', ['dist-html', 'accessibility']);

  // Distribution JS
  grunt.registerTask('dist-js', ['concat', 'uglify']);

  // Distribution CSS
  grunt.registerTask('dist-css', ['sass', 'autoprefixer', 'copy:styles', 'cssmin:minifyCore', 'cssmin:minifyThemes', 'usebanner']);

  // Distribution DOCS
  grunt.registerTask('dist-docs', ['clean:docs', 'dtdocs', 'jekyll:docs', 'copy:components']);

  // Distribution Task
  grunt.registerTask('dist', ['clean:dist', 'dist-css', 'copy:assets', 'dist-js']);

  // Default Task
  grunt.registerTask('default', ['test', 'dist']);

  // Development Task
  grunt.registerTask('serve', ['clean:server', 'jekyll:server', 'sass:core', 'sass:themes', 'autoprefixer:core', 'autoprefixer:themes', 'connect:livereload', 'watch']);

  // Version Change
  // grunt change-version-number --oldver=A.B.C --newver=X.Y.Z
  // check manually before commit => this is just a search and replace for all files
  grunt.registerTask('change-version-number', 'sed');
};
