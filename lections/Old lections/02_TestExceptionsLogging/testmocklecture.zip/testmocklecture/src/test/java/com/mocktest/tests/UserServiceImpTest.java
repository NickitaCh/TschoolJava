package com.mocktest.tests;

import com.mocktest.model.User;
import com.mocktest.service.api.UserService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * Created by aleksandrprendota on 14.05.17.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceImpTest {

    @Autowired
    private UserService userService;

    @Test
    public void testUserById(){
        User user = userService.getUserById(1L);
        Assert.assertEquals(user.getName(), "Sasha");
    }

    @Test
    public void testFindAllUsers(){
        List<User> users = userService.getAllUsers();
        Assert.assertTrue(users.size() > 0);
    }

    @Test
    public void testUserByEmail(){
        User user = userService.getUserByEmail("S@s");
        Assert.assertEquals(user.getName(), "Sasha");
    }

    @Test
    public void testLogic(){
        User user = userService.userDoSomething(1L);
        Assert.assertTrue(user.isДействие());

    }

    @After
    public void after(){
        User user = userService.getUserById(1L);
        user.setДействие(false);
    }

}
