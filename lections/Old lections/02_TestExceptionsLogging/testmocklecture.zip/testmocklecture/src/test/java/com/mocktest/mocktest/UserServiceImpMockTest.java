package com.mocktest.mocktest;


import com.mocktest.model.User;
import com.mocktest.repository.UserRepository;
import com.mocktest.service.imp.UserServiceImp;
import com.mocktest.service.Палка_ковырялка;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by aleksandrprendota on 14.05.17.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserServiceImpMockTest {

    private User user;


    @Before
    public void setUp() {
        user = new User();
        user.setId(1L);
        user.setEmail("pren@mail.ru");
    }


    @Mock
    private UserRepository userRepository;

    @Mock
    private Палка_ковырялка палка_ковырялка;

    @InjectMocks
    private UserServiceImp userServiceImp;

    @Test
    public void testMockGetUsersById(){
        // prepare
        when(userRepository.findOne(1L)).thenReturn(user);
        // do
        userServiceImp.getUserById(user.getId());
        // verify
        verify(userRepository).findOne(user.getId());
    }

    @Test
    public void testMockGetUsersByEmail(){
        when(userRepository.findByEmail("pren@mail.ru")).thenReturn(user);
        userServiceImp.getUserByEmail((user.getEmail()));
        verify(userRepository).findByEmail(user.getEmail());
    }


    @Test
    public void testMockGetUsers(){
        when(userRepository.findAll()).thenReturn(new ArrayList<User>());
        userServiceImp.getAllUsers();
        verify(userRepository).findAll();
    }

    @Test
    public void testLogic(){
        when(палка_ковырялка.пофикситьЧето()).thenReturn(true);
        when(userRepository.findOne(1L)).thenReturn(user);
        when(userRepository.save(user)).thenReturn(user);
        userServiceImp.userDoSomething(1L);
        verify(userRepository).save(user);
        verify(палка_ковырялка).пофикситьЧето();
        verify(userRepository).findOne(user.getId());
    }
}
