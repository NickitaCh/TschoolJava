package com.mocktest;

import com.mocktest.mocktest.UserServiceImpMockTest;
import com.mocktest.tests.UserServiceImpTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
		UserServiceImpMockTest.class,
		UserServiceImpTest.class
})
public class DemoApplicationTests {

}
