package com.mocktest.service.imp;

import com.mocktest.model.User;
import com.mocktest.repository.UserRepository;
import com.mocktest.service.api.UserService;
import com.mocktest.service.Палка_ковырялка;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by aleksandrprendota on 14.05.17.
 */
@Service
public class UserServiceImp implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private Палка_ковырялка палка_ковырялка;


    @Override
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public User getUserById(long id) {
        return userRepository.findOne(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User userDoSomething(long id){
        User userUpdated = userRepository.findOne(id);
        userUpdated.setДействие(палка_ковырялка.пофикситьЧето());
        return userRepository.save(userUpdated);
    }
}
