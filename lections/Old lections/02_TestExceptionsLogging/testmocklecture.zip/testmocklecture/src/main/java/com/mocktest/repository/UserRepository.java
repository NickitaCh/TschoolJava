package com.mocktest.repository;

import com.mocktest.model.User;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by aleksandrprendota on 14.05.17.
 */
@Repository
public class UserRepository {

    /**
     *  It's our database =)
     */
    private static final ArrayList<User> users =
            new ArrayList<User>(
                    Arrays.asList(
                            new User(1L,"Sasha@mail.ru", "qwerty", "Sasha", "Ярославль",false),
                            new User(2L,"Andrey@gmail.com", "12345","Andrey", "Санкт-Петербург",false),
                            new User(3L,"Marina@t-sys.com", "admin","Marina", "Москва",false),
                            new User(4L,"Vova@index.com", "123456789","Vladimir", "Санкт-Петербург",false),
                            new User(5L,"Leha@rambler.ru", "asdf","Alexey", "Сочи",false),
                            new User(6L,"Alla@t-sys.com", "alla123","Alla", "Санкт-Петербург",false)
                    ));

    public List<User> findAll(){
        return users;
    }

    public User findByEmail(String email){
        for (User user : users) {
            if (user.getEmail().equals(email)){
                return user;
            }
        }
        return null;
    }



    public User findOne(long id){
        for (User user : users) {
            if (user.getId() == id){
                return user;
            }
        }
        return null;
    }


     public User save(User user){
       return user;
     }

}
