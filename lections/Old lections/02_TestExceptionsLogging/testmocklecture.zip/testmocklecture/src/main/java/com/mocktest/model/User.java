package com.mocktest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by aleksandrprendota on 14.05.17.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    public long id;
    public String email;
    public String password;
    public String name;
    public String город;
    public boolean действие;

}
