package com.mocktest.controller;

import com.mocktest.model.User;
import com.mocktest.service.api.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by aleksandrprendota on 09.07.17.
 */
@RestController
@RequestMapping(path = "/api")
public class UserController{

    @Autowired
    private UserService userService;

    /**
     * Show list of users
     * @return
     */
    @RequestMapping(value = "/users",method = RequestMethod.GET)
    public List<User> getAll() {
        return userService.getAllUsers();
    }

    /**
     * Get user by user id
     * @param id
     * @return
     */
    @RequestMapping(value = "/email/{id}",method = RequestMethod.GET)
    public User getUserByEmail(@PathVariable Long id){
        return userService.getUserById(id);
    }


}