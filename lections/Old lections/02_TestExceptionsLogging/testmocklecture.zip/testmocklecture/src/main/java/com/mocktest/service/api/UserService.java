package com.mocktest.service.api;

import com.mocktest.model.User;

import java.util.List;

/**
 * Created by aleksandrprendota on 09.07.17.
 */
public interface UserService {
    List<User> getAllUsers();
    User getUserById(long id);
    public User getUserByEmail(String email);
    User userDoSomething(long id);
}
