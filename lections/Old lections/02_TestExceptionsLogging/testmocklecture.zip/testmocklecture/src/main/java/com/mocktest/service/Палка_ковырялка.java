package com.mocktest.service;

import org.springframework.stereotype.Service;

/**
 * Created by aleksandrprendota on 06.07.17.
 */
@Service
public class Палка_ковырялка {

    /*
    Может случится так, что необходимо добавить больше логики
     */
    public Boolean пофикситьЧето(){
        System.out.println("ФИКСЮ....");
        return true;
    }
}
