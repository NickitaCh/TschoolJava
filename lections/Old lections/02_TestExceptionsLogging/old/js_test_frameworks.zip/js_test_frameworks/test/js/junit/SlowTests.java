package js.junit;

public interface SlowTests {

}
