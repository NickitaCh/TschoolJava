package js.testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGTest3 {
	
	@Test
	public void test() {
		Assert.assertTrue(true);
	}

}
