package js.testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGTest2 {
	
	@Test
	public void test() {
		Assert.assertTrue(true);
	}

}
