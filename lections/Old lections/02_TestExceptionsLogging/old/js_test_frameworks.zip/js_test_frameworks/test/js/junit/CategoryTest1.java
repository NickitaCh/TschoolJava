package js.junit;

import org.junit.Assert;
import org.junit.Test;

public class CategoryTest1 {
	
	@Test
	public void test() {
		Assert.assertTrue(true);
	}

}
