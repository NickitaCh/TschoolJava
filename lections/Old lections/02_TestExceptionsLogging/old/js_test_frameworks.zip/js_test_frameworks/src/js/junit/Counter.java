package js.junit;

public interface Counter {
	int incrementAndGet();
}


