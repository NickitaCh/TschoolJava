package js.jpa.pk.relation.inheritance;

import javax.persistence.Entity;

@Entity
public class Plane extends Vehicle {
	
	private String carFeature;

}
