package js.jpa.pk;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SimpleProject {
	
	@Id
	String id;

}
