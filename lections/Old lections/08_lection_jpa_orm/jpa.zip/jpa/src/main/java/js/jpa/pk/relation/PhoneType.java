package js.jpa.pk.relation;

public enum PhoneType {
	
	HOME,
	WORK,
	MOBILE

}
