package js.jpa.pk;

import java.io.Serializable;

public class ProjectId implements Serializable {
	int departmentId;
	long projectId;
	
	//equals hashCode e.t.c
}