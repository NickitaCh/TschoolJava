package com.tsystems.javaschool.websecurity;

import java.security.Principal;
import java.util.Collection;

public class SimpleUserPrincipal implements Principal {

    private final String name;
    private final Collection<String> roles;

    public SimpleUserPrincipal(String name, Collection<String> roles) {
        this.name = name;
        this.roles = roles;
    }

    @Override
    public String getName() {
        return name;
    }

    public Collection<String> getRoles() {
        return roles;
    }
}
