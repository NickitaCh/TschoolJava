package com.tsystems.javaschool.websecurity;

import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class AuthenticatedServletRequestWrapper extends HttpServletRequestWrapper {

    final SimpleUserPrincipal userPrincipal;

    public AuthenticatedServletRequestWrapper(SimpleUserPrincipal userPrincipal, HttpServletRequest request) {
        super(request);
        this.userPrincipal = userPrincipal;
    }

    @Override
    public String getRemoteUser() {
        return userPrincipal.getName();
    }

    @Override
    public boolean isUserInRole(String role) {
        return userPrincipal.getRoles().contains(role);
    }

    @Override
    public Principal getUserPrincipal() {
        return userPrincipal;
    }
}
