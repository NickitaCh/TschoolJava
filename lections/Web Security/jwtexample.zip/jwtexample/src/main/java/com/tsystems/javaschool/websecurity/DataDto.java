package com.tsystems.javaschool.websecurity;

public class DataDto {

    private String text;
    private String user;
    private boolean powerUser;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public boolean isPowerUser() {
        return powerUser;
    }

    public void setPowerUser(boolean powerUser) {
        this.powerUser = powerUser;
    }
}
