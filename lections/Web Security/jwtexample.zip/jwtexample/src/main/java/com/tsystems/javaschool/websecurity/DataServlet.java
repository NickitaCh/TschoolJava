package com.tsystems.javaschool.websecurity;

import java.io.IOException;
import java.util.Date;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet(urlPatterns = {"/protected"})
public class DataServlet extends HttpServlet {

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");

        DataDto dataDto = new DataDto();
        dataDto.setText(new Date().toString());
        dataDto.setUser(req.getRemoteUser());
        dataDto.setPowerUser(req.isUserInRole("poweruser"));

        resp.getWriter().print(objectMapper.writeValueAsString(dataDto));
    }
}
