package com.tsystems.javaschool.websecurity;

public class TokenDto {

    String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
